try:
    from bp_cupid.models import *
except ImportError:
    pass
