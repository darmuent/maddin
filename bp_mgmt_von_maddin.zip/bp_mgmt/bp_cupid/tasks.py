from celery import shared_task
from django.core.cache import cache

from .models import (
    BPBlock,
    BPPlatz,
    BPZeitraum,
    Gewicht,
    Praxis,
    Student,
)

import logging
logger = logging.getLogger(__name__)

LOCK_EXPIRE = 60 * 5
BERECHNE_GEWICHTE_LOCK_ID = 'berechne_gewichte_lock'
VERTEILE_BP_PLAETZE_LOCK_ID = 'verteile_bp_plaetze_lock'


@shared_task
def berechne_gewichte(bp_verwaltungszeitraum_id):
    """
    Berechnet alle Gewichte (Scores) zwischen Studenten und Praxen.
    """

    if cache.add(BERECHNE_GEWICHTE_LOCK_ID, True, LOCK_EXPIRE):
        try:
            Gewicht.objects.filter(
                student__bp_verwaltungszeitraum__id=bp_verwaltungszeitraum_id
            ).delete()

            praxen = Praxis.objects.filter(ist_aktiv=True)
            studenten = Student.objects.filter(
                bp_verwaltungszeitraum_id=bp_verwaltungszeitraum_id,
                hat_fragebogen_ausgefuellt=True,
            )

            gs = (Gewicht.berechne(s, p) for s in studenten for p in praxen)
            Gewicht.objects.bulk_create(gs)
        finally:
            cache.delete(BERECHNE_GEWICHTE_LOCK_ID)


@shared_task
def berechne_gewichte_von_praxis(praxis_id):
    """
    Berechnet die Gewichte einer Praxis, wenn sie aktiv ist, und allen
    Studenten, die den Fragebogen ausgefüllt haben.
    """
    praxis = Praxis.objects.get(id=praxis_id)
    studenten = Student.objects.filter(hat_fragebogen_ausgefuellt=True)

    Gewicht.objects.filter(praxis=praxis).delete()

    if praxis.ist_aktiv:
        gs = (Gewicht.berechne(s, praxis) for s in studenten)
        Gewicht.objects.bulk_create(gs)


@shared_task
def berechne_gewichte_von_student(student_id):
    """
    Berechnet die Gewichte eines Studenten, sofern der Fragebogen ausgefüllt
    wurde, und allen Praxen, die aktiv sind.
    """
    student = Student.objects.get(id=student_id)
    praxen = Praxis.objects.filter(ist_aktiv=True)

    Gewicht.objects.filter(student=student).delete()

    if student.hat_fragebogen_ausgefuellt:
        gs = (Gewicht.berechne(student, p) for p in praxen)
        Gewicht.objects.bulk_create(gs)


@shared_task
def verteile_studenten_task(anzahl=120, bp_blocklimit=30, bp_bloecke=None, loeschen=False): # noqa
    if cache.add(VERTEILE_BP_PLAETZE_LOCK_ID, True, LOCK_EXPIRE):
        try:
            gewaehlte_bp_bloecke = BPBlock.objects.filter(id__in=bp_bloecke)
            verw_zr = gewaehlte_bp_bloecke.first().bp_verwaltungszeitraum
            bp_blocklimit = int(bp_blocklimit)
            anzahl = int(anzahl)

            if loeschen:
                loesche_alle_automatisch_vergebenen_bp_plaetze(verw_zr)

            # erst verteilen wir alle Härtefälle:
            anzahl_verteilte_haertefaelle = 0
            if anzahl > 0:
                anzahl_verteilte_haertefaelle = verteile_haertefaelle(
                    anzahl,
                    bp_blocklimit,
                    gewaehlte_bp_bloecke
                )

            # und dann die restlichen Studenten:
            anzahl_restliche = anzahl - anzahl_verteilte_haertefaelle
            if anzahl_restliche > 0:
                verteile_normale_studenten(
                    anzahl_restliche,
                    bp_blocklimit,
                    gewaehlte_bp_bloecke
                )

        finally:
            cache.delete(VERTEILE_BP_PLAETZE_LOCK_ID)


def verteile_haertefaelle(anzahl, bp_blocklimit, bp_bloecke):
    """
    Sucht 'anzahl' Härtefälle raus und verteilt diese.
    """
    bp_verw_zr = bp_bloecke.first().bp_verwaltungszeitraum
    haertefaelle = Student.objects.frei().filter(
        hat_fragebogen_ausgefuellt=True,
        bp_verwaltungszeitraum=bp_verw_zr,
        ist_haertefall=True,
    ).prefetch_related(
        'gewichte'
    ).order_by('?')[:anzahl]

    logger.debug('Starte Verteilung der Härtefälle')
    logger.debug('Anzahl: {}, Blocklimit: {}, BP-Blöcke: {}'.format(
            anzahl, bp_blocklimit, bp_bloecke
        )
    )

    anzahl_verteilte_haertefaelle = verteile_studenten(
        haertefaelle,
        bp_blocklimit,
        bp_bloecke
    )

    logger.debug(
        'Verteilung der Härtefälle beendet: {} verteilt'.format(
            anzahl_verteilte_haertefaelle,
        )
    )

    return anzahl_verteilte_haertefaelle


def verteile_normale_studenten(anzahl=120, bp_blocklimit=30, bp_bloecke=None):
    """
    Nimmt zufällig 'anzahl' freie Studenten, die den Fragebogen ausgefüllt
    haben, und verteilt sie auf die übergebenen BP-Blöcke.
    """
    bp_verw_zr = bp_bloecke.first().bp_verwaltungszeitraum
    normale_studenten = Student.objects.frei().filter(
        hat_fragebogen_ausgefuellt=True,
        bp_verwaltungszeitraum=bp_verw_zr,
    ).prefetch_related(
        'gewichte__praxis__bpplatzbegrenzung'
    ).order_by('?')[:anzahl]

    logger.debug('Starte Verteilung der normalen Studenten')
    logger.debug(
        'Anzahl: {}, Blocklimit: {}, BP-Blöcke: {}'.format(
            anzahl, bp_blocklimit, bp_bloecke,
        )
    )

    anzahl_verteilte_bp_plaetze = verteile_studenten(
        normale_studenten,
        bp_blocklimit,
        bp_bloecke
    )

    logger.debug(
        'Verteilung der normalen Studenten beendet: {} verteilt'.format(
            anzahl_verteilte_bp_plaetze,
        )
    )

    return anzahl_verteilte_bp_plaetze


def verteile_studenten(studenten, bp_blocklimit, bp_bloecke):
    bp_verw_zr = bp_bloecke.first().bp_verwaltungszeitraum
    gewaehlte_bp_zeitraeume = BPZeitraum.objects.filter(
        bp_block__in=bp_bloecke
    )
    verteilte_bp_plaetze = []
    studenten_ohne_platz = []
    """
    Normalerweise könnte man nach dem Verteilen eines BP-Platzes mit
    s.hat_bp_platz() prüfen, ob ein BP-Platz vergeben wurde und dann zum
    nächsten Studenten springen. Anscheinend geht das nicht oder die
    Datenbankanfrage ist zu langsam. Daher führen wir einfach ein Flag ein und
    setzen es, wenn ein BP-Platz verteilt wurde.
    """
    akt_student_hat_bp_platz = False

    """
    Wir gehen die zufällig ausgesuchten Studenten der Reihe nach durch:
    """
    for s in studenten:
        akt_student_hat_bp_platz = False

        if s.extern:
            logger.debug('{} macht BP extern. Wird übersprungen.'.format(s))
            continue

        logger.debug('Verteile {}'.format(s))
        """
        Bei einem Studenten gehen wir die Gewichte vom höchsten zum niedrigsten
        durch:
        """
        gewichte = s.gewichte.order_by('-wert')
        for g in gewichte:
            praxis = g.praxis

            logger.debug('Probiere Praxis: {}'.format(praxis))

            """
            Wenn die Praxis inaktiv ist, dann übergehen wir sie.
            """
            if not praxis.ist_aktiv:
                logger.debug(
                    '{} ist nicht aktiv und wird übersprungen.'.format(
                        praxis
                    )
                )
                continue

            """
            Überprüfe die BP-Platzbegrenzung; wenn das Limit der Praxis
            erreicht ist, gehe zur nächsten:
            """
            if not praxis.bpplatzbegrenzung_erfuellt(bp_verw_zr):
                logger.debug(
                    'BP-Platzbegrenzung: '
                    'das BP-Platzlimit der Praxis {} ist erreicht.'.format(
                        praxis,
                    )
                )
                continue

            gewaehlte_freie_zeitraeume = praxis.freie_bp_zeitraeume.filter(
                id__in=gewaehlte_bp_zeitraeume
            )
            if not gewaehlte_freie_zeitraeume.exists():
                logger.debug('{} hat keine freien Zeiträume.'.format(praxis))
                continue

            for z in gewaehlte_freie_zeitraeume:
                """
                Wenn die Praxis in den BP-Zeiträumen des BP-Blocks noch einen
                freien BP-Zeitraum hat und das Blocklimit noch nicht erreicht
                ist, dann wird der BP-Platz vergeben:
                """
                if (z.bp_block.anzahl_bp_plaetze < bp_blocklimit):
                    p = BPPlatz.vergib_bp_platz(s.id, praxis.id, z.id)
                    akt_student_hat_bp_platz = True
                    verteilte_bp_plaetze.append(p)
                    logger.debug(
                        '{} verteilt: {}'.format(s, p)
                    )
                    break
                else:
                    logger.debug(
                        'Blocklimit bei Block {} erreicht.'.format(
                            z.bp_block,
                        )
                    )

            """
            Falls ein BP-Platz vergeben wurde, brechen wir aus und gehen zum
            nächsten Studenten:
            """
            if akt_student_hat_bp_platz:
                break

        """
        Falls ein Student am Ende immer noch keinen Platz hat, müssen wir das
        mal loggen:
        """
        if not akt_student_hat_bp_platz:
            studenten_ohne_platz.append(s)

    if studenten_ohne_platz:
        logger.debug(
            'Studenten ohne BP-Platz: {}'.format(studenten_ohne_platz)
        )

    """
    Wir geben die Anzahl der vergebenen BP-Plätze zurück.
    """
    return len(verteilte_bp_plaetze)


def loesche_alle_automatisch_vergebenen_bp_plaetze(bp_verwaltungszeitraum):
    """
    Löscht alle automatisch vergebenen BP-Plätze des übergebenen
    BP-Verwaltungszeitraums
    """
    logger.debug(
        'Lösche alle automatisch vergebenen BP-Plätze '
        'des BP-Verwaltungszeitraums {}'.format(bp_verwaltungszeitraum)
    )
    BPPlatz.objects.filter(
        manuell=False,
        student__bp_verwaltungszeitraum=bp_verwaltungszeitraum,
    ).delete()
    logger.debug('BP-Plätze gelöscht')
