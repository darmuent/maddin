default_app_config = 'bp_cupid.apps.BPCupidConfig'
