from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator

telefon_regex = RegexValidator(
    regex=r'^\+?1?\d{9,15}$',
    message="Telefonnummer muss von folgendem Format sein: '+999999999'. "
    "Es sind bis zu 15 Ziffern erlaubt."
)


def validate_note(note):
    """
    Eine Note kann entweder
        nicht vorhanden (== 0),
        eine ordentliche Note (zwischen 1 und 4), oder
        nicht bestanden (== 5) sein.
    Andernfalls schmeißen wir eine Exception.
    """
    if not (note == 0 or 1 <= note <= 4 or note == 5):
        raise ValidationError(
            'Das ist keine ordentliche Note. '
            'Eine Note kann 0 sein (bisher nicht vorhanden), '
            'zwischen 1 und 4 liegen (bestanden), oder '
            'gleich 5 sein (nicht bestanden).'
        )
