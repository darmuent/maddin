from django.test import TestCase

from datetime import date

from bp_cupid.models import (
    BPVerwaltungszeitraum,
    PJBlock,
    PJPlatz,
    PJVerwaltungszeitraum,
    PJZeitraum,
    Praxis,
    Student,
)


class TestPraxisPJ(TestCase):
    def setUp(self):
        self.pj_vwzr = PJVerwaltungszeitraum(
            name='Test PJ VW',
            anfang=date(2017, 1, 1),
            ende=date(2017, 12, 31),
        )
        self.pj_vwzr.save()

        self.tertial = PJBlock(
            name='1. Tertial',
            pj_verwaltungszeitraum=self.pj_vwzr
        )
        self.tertial.save()

        self.zr1 = PJZeitraum(
            anfang=date(2017, 1, 1),
            ende=date(2017, 3, 31),
            pj_block=self.tertial,
        )
        self.zr1.save()

        self.zr2 = PJZeitraum(
            anfang=date(2017, 1, 1),
            ende=date(2017, 2, 15),
            pj_block=self.tertial,
        )
        self.zr2.save()

        self.pr1 = Praxis(
            vorname='Gregory',
            name='House',
        )
        self.pr1.save()

        self.pr1.pj_zeitraeume.add(self.zr1, self.zr2)

    def test_freie_pj_zeitraeume(self):
        """
        Die Praxis bietet 2 PJ-Zeiträume an und keiner von denen ist belegt.
        Also müssten sie in 'freie_pj_zeitraeume' enthalten sein.
        """
        self.assertIn(
            self.zr1,
            self.pr1.freie_pj_zeitraeume.all(),
        )
        self.assertIn(
            self.zr2,
            self.pr1.freie_pj_zeitraeume.all(),
        )

    def test_pj_zeitraeume_nach_platzvergabe(self):
        """
        Wenn wir einen PJ-Platz vergeben, dann sollten die PJ-Zeiträume nicht
        mehr frei sein.
        """
        self.assertNotIn(
            self.zr1,
            self.pr1.belegte_pj_zeitraeume.all(),
        )
        self.assertNotIn(
            self.zr2,
            self.pr1.belegte_pj_zeitraeume.all(),
        )

        bp_vwzr = BPVerwaltungszeitraum.objects.create(
            name='Test BP VW',
            anfang=date(2017, 1, 1),
            ende=date(2017, 6, 30),
        )
        st1 = Student.objects.create(
            vorname='Albert',
            name='Einstein',
            mat_nr=1,
            bp_verwaltungszeitraum=bp_vwzr,
        )

        PJPlatz.objects.create(
            student=st1,
            praxis=self.pr1,
            pj_zeitraum=self.zr1
        )

        self.assertIn(
            self.zr1,
            self.pr1.belegte_pj_zeitraeume.all(),
        )
        self.assertIn(
            self.zr2,
            self.pr1.belegte_pj_zeitraeume.all(),
        )
        self.assertNotIn(
            self.zr1,
            self.pr1.freie_pj_zeitraeume.all(),
        )
        self.assertNotIn(
            self.zr2,
            self.pr1.freie_pj_zeitraeume.all(),
        )

    def test_hasattr_urkunden(self):
        self.assertTrue(hasattr(self.pr1, 'hat_bp_urkunde_erhalten'))
        self.assertTrue(hasattr(self.pr1, 'hat_pj_urkunde_erhalten'))

    def test_hasattr_beginn_der_lehrtaetigkeit(self):
        self.assertTrue(hasattr(self.pr1, 'beginn_bp_lehrtaetigkeit'))
        self.assertTrue(hasattr(self.pr1, 'beginn_pj_lehrtaetigkeit'))
