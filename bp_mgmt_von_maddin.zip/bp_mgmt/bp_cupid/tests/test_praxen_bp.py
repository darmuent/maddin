from django.test import TestCase

from datetime import date

from bp_cupid.models import (
    BPBlock,
    BPPlatz,
    BPVerwaltungszeitraum,
    BPZeitraum,
    Praxis,
    Student,
)


class TestPraxisBP(TestCase):
    def setUp(self):
        self.bp_vwzr = BPVerwaltungszeitraum(
            name='Test BP VW',
            anfang=date(2017, 1, 1),
            ende=date(2017, 6, 30),
        )
        self.bp_vwzr.save()

        self.block = BPBlock(
            name='Block 1',
            bp_verwaltungszeitraum=self.bp_vwzr
        )
        self.block.save()

        self.zr1 = BPZeitraum(
            anfang=date(2017, 1, 1),
            ende=date(2017, 1, 15),
            bp_block=self.block,
        )
        self.zr1.save()
        self.zr2 = BPZeitraum(
            anfang=date(2017, 1, 8),
            ende=date(2017, 1, 23),
            bp_block=self.block,
        )
        self.zr2.save()

        self.pr1 = Praxis(
            vorname='Gregory',
            name='House',
        )
        self.pr1.save()

        self.pr1.bp_zeitraeume.all().delete()
        self.pr1.bp_zeitraeume.add(self.zr1, self.zr2)

    def test_kapazitaet(self):
        """
        Die Praxis bietet 2 Zeiträume an, die sich jedoch überlagern. Also
        müsste die Kapazität vom ersten Block 1 betragen.
        """
        self.assertEqual(
            self.pr1.kapazitaet(self.block),
            1
        )

    def test_freie_bp_zeitraeume(self):
        """
        Die Praxis bietet 2 Zeiträume an und keiner von denen ist belegt. Also
        müssten sie in 'freie_bp_zeitraeume' enthalten sein.
        """
        self.assertIn(
            self.zr1,
            self.pr1.freie_bp_zeitraeume.all(),
        )
        self.assertIn(
            self.zr2,
            self.pr1.freie_bp_zeitraeume.all(),
        )

    def test_bp_zeitraeume_nach_platzvergabe(self):
        self.assertNotIn(
            self.zr1,
            self.pr1.belegte_bp_zeitraeume.all(),
        )
        self.assertNotIn(
            self.zr2,
            self.pr1.belegte_bp_zeitraeume.all(),
        )

        st1 = Student.objects.create(
            vorname='Albert',
            name='Einstein',
            mat_nr=1,
            bp_verwaltungszeitraum=self.bp_vwzr,
        )

        BPPlatz.vergib_bp_platz(st1.id, self.pr1.id, self.zr1.id)

        self.assertIn(
            self.zr1,
            self.pr1.belegte_bp_zeitraeume.all(),
        )
        # Weil sich zr1 und zr2 überlappen, muss auch zr2 in
        # pr1.belegte_bp_zeitraeume sein:
        self.assertIn(
            self.zr2,
            self.pr1.belegte_bp_zeitraeume.all(),
        )
        self.assertNotIn(
            self.zr1,
            self.pr1.freie_bp_zeitraeume.all(),
        )
        self.assertNotIn(
            self.zr2,
            self.pr1.freie_bp_zeitraeume.all(),
        )

    def test_hasattr_urkunden(self):
        self.assertTrue(hasattr(self.pr1, 'hat_bp_urkunde_erhalten'))
        self.assertTrue(hasattr(self.pr1, 'hat_pj_urkunde_erhalten'))

    def test_hasattr_beginn_der_lehrtaetigkeit(self):
        self.assertTrue(hasattr(self.pr1, 'beginn_bp_lehrtaetigkeit'))
        self.assertTrue(hasattr(self.pr1, 'beginn_pj_lehrtaetigkeit'))
