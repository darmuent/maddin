"""
Testet die Funktionen von BP-Platz.
"""

from django.test import TestCase
from django.core.exceptions import ValidationError

from datetime import date

from bp_cupid.models import (
    BPBlock,
    BPPlatz,
    BPVerwaltungszeitraum,
    BPZeitraum,
    Praxis,
    Student,
)


class TestPlatz(TestCase):
    def setUp(self):
        self.bp_verwaltungszeitraum = BPVerwaltungszeitraum(
            name='Test BP VW',
            anfang=date(2017, 1, 1),
            ende=date(2017, 12, 31),
        )
        self.bp_verwaltungszeitraum.save()

        self.bp_block = BPBlock(
            name='Block 1',
            bp_verwaltungszeitraum=self.bp_verwaltungszeitraum
        )
        self.bp_block.save()

        self.zr1 = BPZeitraum(
            anfang=date(2017, 1, 1),
            ende=date(2017, 1, 15),
            bp_block=self.bp_block,
        )
        self.zr1.save()
        self.zr2 = BPZeitraum(
            anfang=date(2017, 1, 8),
            ende=date(2017, 1, 22),
            bp_block=self.bp_block,
        )
        self.zr2.save()
        self.zr3 = BPZeitraum(
            anfang=date(2017, 1, 15),
            ende=date(2017, 1, 29),
            bp_block=self.bp_block,
        )
        self.zr3.save()

        self.st1 = Student(
            vorname='Albert',
            name='Einstein',
            mat_nr=1,
            bp_verwaltungszeitraum=self.bp_verwaltungszeitraum,
        )
        self.st1.save()
        self.st2 = Student(
            vorname='Isaac',
            name='Newton',
            mat_nr=2,
            bp_verwaltungszeitraum=self.bp_verwaltungszeitraum,
        )
        self.st2.save()

        self.pr1 = Praxis(
            vorname='Gregory',
            name='House',
        )
        self.pr1.save()

        self.pr1.bp_zeitraeume.all().delete()
        self.pr1.bp_zeitraeume.add(self.zr1, self.zr2)
        self.pr1.save()

    def test_nur_ein_student_pro_bp_zeitraum(self):
        """
        Pro Praxis und Zeitraum kann nur ein Student eingeteilt werden.

        Hier versuchen wir zwei Studenten zu einer Praxis in einem Zeitraum
        zuzuordnen.
        """
        BPPlatz.vergib_bp_platz(self.st1.id, self.pr1.id, self.zr1.id)
        with self.assertRaises(ValidationError):
            BPPlatz.vergib_bp_platz(self.st2.id, self.pr1.id, self.zr1.id)

    def test_keine_ueberlappenden_bp_zeitraeume(self):
        """
        Falls ein Zeitraum von einem Studenten belegt ist und ein anderer
        Zeitraum mit diesem überlappt, dann kann letzterer nicht belegt werden.

        Hier vergeben wir den ersten Zeitraum an Albert. Wenn wir versuchen,
        den zweiten Zeitraum an Isaac zu vergeben, müsste eine Exception
        geworfen werden.
        """
        BPPlatz.vergib_bp_platz(self.st1.id, self.pr1.id, self.zr1.id)
        with self.assertRaises(ValidationError):
            BPPlatz.vergib_bp_platz(self.st2.id, self.pr1.id, self.zr2.id)

    def test_bp_zeitraum_wird_nicht_angeboten(self):
        """
        Falls eine Praxis den Zeitraum gar nicht erst anbietet, müsste eine
        Exception geworfen werden.
        """
        with self.assertRaises(ValidationError):
            BPPlatz.vergib_bp_platz(self.st1.id, self.pr1.id, self.zr3.id)

    def test_praxis_voll_belegt(self):
        """
        Wenn wir einen Zeitraum der Praxis belegen, müsste sie voll belegt
        sein. Davor nicht.
        """

        self.assertFalse(self.pr1.voll_belegt(self.bp_verwaltungszeitraum))
        BPPlatz.vergib_bp_platz(self.st1.id, self.pr1.id, self.zr1.id)
        self.assertTrue(self.pr1.voll_belegt(self.bp_verwaltungszeitraum))

    def test_freie_bp_zeitraeume_in_bp_block(self):
        """
        Zu Beginn müsste unsere Praxis die beiden Zeiträume 1 und 2 als 'frei'
        erachten. Wenn wir danach einen Platz vergeben, müsste sie keine freien
        Plätze mehr haben.
        """
        self.assertEqual(
            self.pr1.freie_bp_zeitraeume_in_bp_block(self.bp_block),
            [self.zr1, self.zr2]
        )
        self.assertTrue(
            self.pr1.hat_freien_bp_zeitraum_in_bp_block(self.bp_block)
        )

        BPPlatz.vergib_bp_platz(self.st1.id, self.pr1.id)

        self.assertEqual(
            self.pr1.freie_bp_zeitraeume_in_bp_block(self.bp_block),
            []
        )
        self.assertFalse(
            self.pr1.hat_freien_bp_zeitraum_in_bp_block(self.bp_block)
        )
