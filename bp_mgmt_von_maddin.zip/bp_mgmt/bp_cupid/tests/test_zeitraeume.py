from django.test import TestCase

from datetime import date

from bp_cupid.models import (
    BPBlock,
    BPVerwaltungszeitraum,
    BPZeitraum,
    PJBlock,
    PJVerwaltungszeitraum,
    PJZeitraum,
)


class TestZeitraum(TestCase):
    def setUp(self):
        self.bp_vwzr = BPVerwaltungszeitraum(
            name='Test BP VW',
            anfang=date(2017, 1, 1),
            ende=date(2017, 6, 30),
        )
        self.bp_vwzr.save()

        self.bp_block = BPBlock(
            name='Block 1',
            bp_verwaltungszeitraum=self.bp_vwzr
        )
        self.bp_block.save()

        self.zr1 = BPZeitraum(
            anfang=date(2017, 1, 1),
            ende=date(2017, 1, 15),
            bp_block=self.bp_block,
        )
        self.zr1.save()
        self.zr2 = BPZeitraum(
            anfang=date(2017, 1, 8),
            ende=date(2017, 1, 23),
            bp_block=self.bp_block,
        )
        self.zr2.save()

        self.pj_verwzr = PJVerwaltungszeitraum(
            name='Test PJ VW',
            anfang=date(2017, 1, 1),
            ende=date(2017, 12, 31),
        )
        self.pj_verwzr.save()

        self.pj_block = PJBlock(
            name='Block 1',
            pj_verwaltungszeitraum=self.pj_verwzr,
        )
        self.pj_block.save()

        self.pj_zr1 = PJZeitraum(
            anfang=date(2017, 1, 1),
            ende=date(2017, 4, 30),
            pj_block=self.pj_block,
        )
        self.pj_zr1.save()
        self.pj_zr2 = PJZeitraum(
            anfang=date(2017, 3, 1),
            ende=date(2017, 6, 30),
            pj_block=self.pj_block,
        )
        self.pj_zr2.save()

    def test_bpzeitraum(self):
        self.assertIn(
            self.zr1,
            self.zr1.ueberlappende.all()
        )
        self.assertIn(
            self.zr2,
            self.zr1.ueberlappende.all()
        )
        self.assertIn(
            self.zr1,
            self.zr2.ueberlappende.all()
        )
        self.assertIn(
            self.zr2,
            self.zr2.ueberlappende.all()
        )

    def test_pjzeitraum(self):
        self.assertIn(
            self.pj_zr1,
            self.pj_zr1.ueberlappende.all()
        )
        self.assertIn(
            self.pj_zr2,
            self.pj_zr1.ueberlappende.all()
        )
        self.assertIn(
            self.pj_zr1,
            self.pj_zr2.ueberlappende.all()
        )
        self.assertIn(
            self.pj_zr2,
            self.pj_zr2.ueberlappende.all()
        )

    def test_bp_und_pj_zeitraeume(self):
        self.assertIn(
            self.zr1,
            self.pj_zr1.ueberlappende_bp.all()
        )
        self.assertIn(
            self.zr2,
            self.pj_zr1.ueberlappende_bp.all()
        )
        self.assertIn(
            self.pj_zr1,
            self.zr1.ueberlappende_pj.all()
        )
        self.assertIn(
            self.pj_zr1,
            self.zr2.ueberlappende_pj.all()
        )
        self.assertNotIn(
            self.pj_zr2,
            self.zr1.ueberlappende_pj.all()
        )
        self.assertNotIn(
            self.pj_zr2,
            self.zr2.ueberlappende_pj.all()
        )
