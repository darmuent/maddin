from django.test import TestCase

from datetime import date

from bp_cupid.models import (
    BPBlock,
    BPPlatz,
    BPVerwaltungszeitraum,
    BPZeitraum,
    Praxis,
    Student,
)


class TestStudent(TestCase):
    def setUp(self):
        self.bp_verwaltungszeitraum = BPVerwaltungszeitraum(
            name='Test BP VW',
            anfang=date(2017, 1, 1),
            ende=date(2017, 12, 31),
        )
        self.bp_verwaltungszeitraum.save()

        self.bp_block = BPBlock(
            name='Block 1',
            bp_verwaltungszeitraum=self.bp_verwaltungszeitraum
        )
        self.bp_block.save()

        self.zr1 = BPZeitraum(
            anfang=date(2017, 1, 1),
            ende=date(2017, 1, 15),
            bp_block=self.bp_block,
        )
        self.zr1.save()
        self.zr2 = BPZeitraum(
            anfang=date(2017, 1, 8),
            ende=date(2017, 1, 22),
            bp_block=self.bp_block,
        )
        self.zr2.save()
        self.zr3 = BPZeitraum(
            anfang=date(2017, 1, 15),
            ende=date(2017, 1, 29),
            bp_block=self.bp_block,
        )
        self.zr3.save()

        self.st1 = Student(
            vorname='Albert',
            name='Einstein',
            mat_nr=1,
            bp_verwaltungszeitraum=self.bp_verwaltungszeitraum,
        )
        self.st1.save()
        self.st2 = Student(
            vorname='Isaac',
            name='Newton',
            mat_nr=2,
            bp_verwaltungszeitraum=self.bp_verwaltungszeitraum,
        )
        self.st2.save()

        self.pr1 = Praxis(
            vorname='Gregory',
            name='House',
        )
        self.pr1.save()

        self.pr1.bp_zeitraeume.all().delete()
        self.pr1.bp_zeitraeume.add(self.zr1, self.zr2)
        self.pr1.save()

    def test_freie_studenten(self):
        """
        Albert und Isaac müssten anfangs frei sein. Nach einer Platzzuweisung
        dürfte Albert nicht mehr frei sein.
        """
        self.assertIn(self.st1, Student.objects.frei())
        self.assertIn(self.st2, Student.objects.frei())

        BPPlatz.vergib_bp_platz(self.st1.id, self.pr1.id, self.zr1.id)

        self.assertNotIn(self.st1, Student.objects.frei())
        self.assertIn(self.st2, Student.objects.frei())

    def test_hasattr_hat_seminar_besucht(self):
        self.assertTrue(hasattr(self.st1, 'hat_seminar_besucht'))
