# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0053_entfernt_ueberfluessigen_whitespace_bei_help_text'),
    ]

    operations = [
        migrations.AddField(
            model_name='verwaltungszeitraum',
            name='anzeige_fuer_fragebogen',
            field=models.TextField(verbose_name='Anzeige für den Fragebogen', blank=True, default='', help_text='So wird der dem Studenten zugeordnete Verwaltungszeitraum in der Überschrift des Fragebogens angezeigt. Für den Verwaltungszeitraum „WS1617“ könnte dieser Text bspw. „WS 2016-17 und SS 2017“ sein.'),
        ),
    ]
