# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0052_landkreise_aendert_beschreibung_von_plzs'),
    ]

    operations = [
        migrations.AlterField(
            model_name='historicalplatz',
            name='manuell',
            field=models.BooleanField(default=False, help_text='Wenn aktiviert, dann wird der Platz bei der automatischen Platzvergabe nicht gelöscht.'),
        ),
        migrations.AlterField(
            model_name='platz',
            name='manuell',
            field=models.BooleanField(default=False, help_text='Wenn aktiviert, dann wird der Platz bei der automatischen Platzvergabe nicht gelöscht.'),
        ),
    ]
