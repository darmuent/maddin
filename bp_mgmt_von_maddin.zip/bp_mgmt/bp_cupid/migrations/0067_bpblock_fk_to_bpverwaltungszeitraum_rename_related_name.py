# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0066_block_zu_bpblock'),
    ]

    operations = [
        migrations.AlterField(
            model_name='bpblock',
            name='bp_verwaltungszeitraum',
            field=models.ForeignKey(verbose_name='BP-Verwaltungszeitraum', related_name='bp_bloecke', to='bp_cupid.BPVerwaltungszeitraum'),
        ),
    ]
