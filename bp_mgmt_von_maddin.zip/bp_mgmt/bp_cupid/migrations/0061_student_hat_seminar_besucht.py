# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0060_student_bundeswehr'),
    ]

    operations = [
        migrations.AddField(
            model_name='historicalstudent',
            name='hat_seminar_besucht',
            field=models.BooleanField(verbose_name='hat Seminar besucht', default=False),
        ),
        migrations.AddField(
            model_name='student',
            name='hat_seminar_besucht',
            field=models.BooleanField(verbose_name='hat Seminar besucht', default=False),
        ),
    ]
