# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0084_praxis_ist_vip'),
    ]

    operations = [
        migrations.CreateModel(
            name='Abrechnungszeitraum',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('name', models.CharField(verbose_name='Name', max_length=100, default='Abrechnungszeitraum 0')),
                ('bp_verwaltungszeitraum', models.ForeignKey(verbose_name='BP-Verwaltungszeitraum', related_name='abrechnungszeitraum', to='bp_cupid.BPVerwaltungszeitraum')),
            ],
            options={
                'verbose_name': 'Abrechnungszeitraum',
                'verbose_name_plural': 'Abrechnungszeiträume',
            },
        ),
        migrations.AlterUniqueTogether(
            name='abrechnungszeitraum',
            unique_together=set([('bp_verwaltungszeitraum', 'name')]),
        ),
    ]
