# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0075_create_historicalbpplatz'),
    ]

    operations = [
        migrations.AlterField(
            model_name='bpplatz',
            name='bp_zeitraum',
            field=models.ForeignKey(verbose_name='BP-Zeitraum', related_name='bp_plaetze', to='bp_cupid.BPZeitraum'),
        ),
        migrations.AlterField(
            model_name='bpzeitraum',
            name='bp_block',
            field=models.ForeignKey(verbose_name='BP-Block', related_name='bp_zeitraeume', to='bp_cupid.BPBlock'),
        ),
    ]
