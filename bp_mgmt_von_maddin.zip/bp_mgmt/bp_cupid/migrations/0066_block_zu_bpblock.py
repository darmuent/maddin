# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0065_kleine_aenderungen'),
    ]

    operations = [
        migrations.RenameModel(
            old_name='Block',
            new_name='BPBlock',
        ),
        migrations.AlterModelOptions(
            name='BPBlock',
            options={
                'verbose_name': 'BP-Block',
                'verbose_name_plural': 'BP-Blöcke',
            },
        ),

        # migrations.CreateModel(
        #     name='BPBlock',
        #     fields=[
        #         ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
        #         ('name', models.CharField(max_length=20)),
        #         ('kapazitaet', models.IntegerField(verbose_name='Kapazität', default=0)),
        #         ('bp_verwaltungszeitraum', models.ForeignKey(verbose_name='BP-Verwaltungszeitraum', related_name='bp_bloecke', to='bp_cupid.BPVerwaltungszeitraum')),
        #     ],
        #     options={
        #         'verbose_name': 'BP-Block',
        #         'verbose_name_plural': 'BP-Blöcke',
        #     },
        # ),

        migrations.AlterField(
            model_name='zeitraum',
            name='block',
            field=models.ForeignKey(
                to='bp_cupid.BPBlock',
                related_name='zeitraeume',
            ),
        ),
        migrations.RenameField(
            model_name='zeitraum',
            old_name='block',
            new_name='bp_block',
        ),

        # migrations.AlterUniqueTogether(
        #     name='block',
        #     unique_together=set([]),
        # ),
        # migrations.RemoveField(
        #     model_name='block',
        #     name='bp_verwaltungszeitraum',
        # ),
        # migrations.RemoveField(
        #     model_name='zeitraum',
        #     name='block',
        # ),
        # migrations.DeleteModel(
        #     name='Block',
        # ),
        # migrations.AddField(
        #     model_name='zeitraum',
        #     name='bp_block',
        #     field=models.ForeignKey(default=0, related_name='zeitraeume', to='bp_cupid.BPBlock'),
        #     preserve_default=False,
        # ),
        # migrations.AlterUniqueTogether(
        #     name='bpblock',
        #     unique_together=set([('name', 'bp_verwaltungszeitraum')]),
        # ),
    ]
