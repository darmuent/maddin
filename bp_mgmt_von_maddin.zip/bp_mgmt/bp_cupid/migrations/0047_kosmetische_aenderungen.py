# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0046_abrechnungsdetail'),
    ]

    operations = [
        migrations.AlterField(
            model_name='student',
            name='abgeneigte_praxen',
            field=models.ManyToManyField(db_table='abgeneigte_praxen', blank=True, to='bp_cupid.Praxis', verbose_name='abgeneigte Praxen', related_name='abgeneigte_praxen'),
        ),
        migrations.AlterField(
            model_name='student',
            name='adresse_priv_unterkunft',
            field=models.TextField(default='', blank=True, verbose_name='Ort+PLZ'),
        ),
        migrations.AlterField(
            model_name='student',
            name='bevorzugte_praxen',
            field=models.ManyToManyField(db_table='bevorzugte_praxen', blank=True, to='bp_cupid.Praxis', verbose_name='bevorzugte Praxen', related_name='bevorzugte_praxen'),
        ),
        migrations.AlterField(
            model_name='student',
            name='sonstiges',
            field=models.TextField(default='', blank=True, verbose_name='Sonstiges'),
        ),
        migrations.AlterField(
            model_name='zeitraum',
            name='ueberlappende',
            field=models.ManyToManyField(db_table='ueberlappende_zeitraeume', blank=True, to='bp_cupid.Zeitraum', verbose_name='Überlappende Zeiträume', related_name='_zeitraum_ueberlappende_+'),
        ),
    ]
