# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0088_setze_abrechnungszeitraeume'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='historicalabrechnungsdetail',
            name='bp_verwaltungszeitraum',
        ),
        migrations.AlterField(
            model_name='abrechnungsdetail',
            name='abrechnungszeitraum',
            field=models.ForeignKey(related_name='abrechnungsdetail', to='bp_cupid.Abrechnungszeitraum'),
        ),
        migrations.AlterUniqueTogether(
            name='abrechnungsdetail',
            unique_together=set([('abrechnungszeitraum', 'praxis')]),
        ),
        migrations.RemoveField(
            model_name='abrechnungsdetail',
            name='bp_verwaltungszeitraum',
        ),
    ]
