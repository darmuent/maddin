# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0038_zusatzinfopraxis'),
    ]

    operations = [
        migrations.AddField(
            model_name='historicalplatz',
            name='pj',
            field=models.BooleanField(default=False, help_text='Gibt an, ob dieser Platz für das praktische Jahr ist.', verbose_name='PJ'),
        ),
        migrations.AddField(
            model_name='platz',
            name='pj',
            field=models.BooleanField(default=False, help_text='Gibt an, ob dieser Platz für das praktische Jahr ist.', verbose_name='PJ'),
        ),
    ]
