# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0048_verwaltungszeitraum_plaetze_fuer_studenten_einsehbar'),
    ]

    operations = [
        migrations.AlterField(
            model_name='evaluation',
            name='note_praktikum',
            field=models.DecimalField(verbose_name='Note für das Praktikum', blank=True, null=True, default=0, help_text='Note als Zahl (z.B. 1 oder 2,5). Falls keine Note vorliegt, einfach leer lassen.', max_digits=2, decimal_places=1),
        ),
    ]
