# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0015_platz'),
    ]

    operations = [
        migrations.AlterUniqueTogether(
            name='block',
            unique_together=set([('name', 'verwaltungszeitraum')]),
        ),
    ]
