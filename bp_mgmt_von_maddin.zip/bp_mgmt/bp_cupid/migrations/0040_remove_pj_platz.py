# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0039_pj_platz'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='historicalplatz',
            name='pj',
        ),
        migrations.RemoveField(
            model_name='platz',
            name='pj',
        ),
    ]
