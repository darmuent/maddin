# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0083_praxis_position'),
    ]

    operations = [
        migrations.AddField(
            model_name='praxis',
            name='ist_vip',
            field=models.BooleanField(verbose_name='ist VIP', default=False, help_text='Wird auf der Karte besonders angezeigt.'),
        ),
    ]
