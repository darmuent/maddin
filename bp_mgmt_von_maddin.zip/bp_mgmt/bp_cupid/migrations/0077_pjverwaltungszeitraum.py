# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0076_alter_fields_on_bpplatz_and_bpzeitraum'),
    ]

    operations = [
        migrations.CreateModel(
            name='PJVerwaltungszeitraum',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('name', models.CharField(max_length=50, unique=True)),
                ('anfang', models.DateField()),
                ('ende', models.DateField()),
            ],
            options={
                'verbose_name': 'PJ-Verwaltungszeitraum',
                'verbose_name_plural': 'PJ-Verwaltungszeiträume',
            },
        ),
    ]
