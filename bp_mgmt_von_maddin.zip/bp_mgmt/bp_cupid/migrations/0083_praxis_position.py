# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import geoposition.fields


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0082_pjplatz_change_id_default'),
    ]

    operations = [
        migrations.AddField(
            model_name='praxis',
            name='position',
            field=geoposition.fields.GeopositionField(max_length=42, blank=True),
        ),
    ]
