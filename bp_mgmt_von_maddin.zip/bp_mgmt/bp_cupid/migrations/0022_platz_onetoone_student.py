# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0020_mitarbeiter'),
    ]

    operations = [
        migrations.AlterField(
            model_name='platz',
            name='student',
            field=models.OneToOneField(related_name='platz', serialize=False, primary_key=True, to='bp_cupid.Student'),
        ),
    ]
