# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0067_bpblock_fk_to_bpverwaltungszeitraum_rename_related_name'),
    ]

    operations = [
        migrations.AlterField(
            model_name='zeitraum',
            name='bp_block',
            field=models.ForeignKey(verbose_name='BP-Block', related_name='zeitraeume', to='bp_cupid.BPBlock'),
        ),
    ]
