# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.core.validators


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0071_platz_zu_bpplatz'),
    ]

    operations = [
        # Platzbegrenzung → BPPlatzbegrenzung
        #
        # migrations.CreateModel(
        #     name='BPPlatzbegrenzung',
        #     fields=[
        #         ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
        #         ('anzahl', models.IntegerField(verbose_name='max. Anzahl BP-Plätze', validators=[django.core.validators.MinValueValidator(0, 'Anzahl darf nicht negativ sein.')])),
        #     ],
        #     options={
        #         'verbose_name': 'BP-Platzbegrenzung',
        #         'verbose_name_plural': 'BP-Platzbegrenzungen',
        #     },
        # ),
        # migrations.AlterUniqueTogether(
        #     name='platzbegrenzung',
        #     unique_together=set([]),
        # ),
        # migrations.RemoveField(
        #     model_name='platzbegrenzung',
        #     name='bp_verwaltungszeitraum',
        # ),
        # migrations.RemoveField(
        #     model_name='platzbegrenzung',
        #     name='praxis',
        # ),
        # migrations.AddField(
        #     model_name='bpplatzbegrenzung',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(related_name='bpplatzbegrenzung', to='bp_cupid.BPVerwaltungszeitraum'),
        # ),
        # migrations.AddField(
        #     model_name='bpplatzbegrenzung',
        #     name='praxis',
        #     field=models.ForeignKey(related_name='bpplatzbegrenzung', to='bp_cupid.Praxis'),
        # ),

        migrations.RenameModel(
            old_name='Platzbegrenzung',
            new_name='BPPlatzbegrenzung',
        ),
        migrations.AlterModelOptions(
            name='BPPlatzbegrenzung',
            options={
                'verbose_name': 'BP-Platzbegrenzung',
                'verbose_name_plural': 'BP-Platzbegrenzungen',
            },
        ),
        migrations.AlterField(
            model_name='BPPlatzbegrenzung',
            name='bp_verwaltungszeitraum',
            field=models.ForeignKey(
                related_name='bpplatzbegrenzung',
                to='bp_cupid.BPVerwaltungszeitraum'
            ),
        ),
        migrations.AlterField(
            model_name='BPPlatzbegrenzung',
            name='praxis',
            field=models.ForeignKey(
                related_name='bpplatzbegrenzung',
                to='bp_cupid.Praxis'
            ),
        ),
        migrations.AlterField(
            model_name='BPPlatzbegrenzung',
            name='anzahl',
            field=models.IntegerField(
                verbose_name='max. Anzahl BP-Plätze',
                validators=[
                    django.core.validators.MinValueValidator(
                        0,
                        'Anzahl darf nicht negativ sein.'
                    )
                ]
            ),
        ),
    ]
