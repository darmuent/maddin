# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import bp_cupid.validators


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0057_student_ist_haertefall'),
    ]

    operations = [
        migrations.AddField(
            model_name='historicalstudent',
            name='note_bp',
            field=models.DecimalField(verbose_name='Note für das Blockpraktikum', default=0, help_text='Note als Zahl (z.B. 1 oder 2,5)', validators=[bp_cupid.validators.validate_note], max_digits=2, decimal_places=1),
        ),
        migrations.AddField(
            model_name='historicalstudent',
            name='note_klausur',
            field=models.DecimalField(verbose_name='Klausurnote', default=0, help_text='Note als Zahl (z.B. 1 oder 2,5)', validators=[bp_cupid.validators.validate_note], max_digits=2, decimal_places=1),
        ),
        migrations.AddField(
            model_name='student',
            name='note_bp',
            field=models.DecimalField(verbose_name='Note für das Blockpraktikum', default=0, help_text='Note als Zahl (z.B. 1 oder 2,5)', validators=[bp_cupid.validators.validate_note], max_digits=2, decimal_places=1),
        ),
        migrations.AddField(
            model_name='student',
            name='note_klausur',
            field=models.DecimalField(verbose_name='Klausurnote', default=0, help_text='Note als Zahl (z.B. 1 oder 2,5)', validators=[bp_cupid.validators.validate_note], max_digits=2, decimal_places=1),
        ),
    ]
