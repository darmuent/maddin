# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0064_verwaltungszeitraum_zu_bpverwaltungszeitraum'),
    ]

    operations = [
        migrations.AlterField(
            model_name='block',
            name='bp_verwaltungszeitraum',
            field=models.ForeignKey(verbose_name='BP-Verwaltungszeitraum', related_name='bloecke', to='bp_cupid.BPVerwaltungszeitraum'),
        ),
        migrations.AlterField(
            model_name='mitarbeiter',
            name='akt_bp_verw_zeitraum',
            field=models.ForeignKey(verbose_name='aktueller BP-Verwaltungszeitraum', default=1, help_text='Bei allen Ansichten werden nur Blöcke und Zeiträume des aktuellen BP-Verwaltungszeitraums angezeigt.', to='bp_cupid.BPVerwaltungszeitraum'),
        ),
        migrations.AlterField(
            model_name='student',
            name='bp_verwaltungszeitraum',
            field=models.ForeignKey(verbose_name='BP-Verwaltungszeitraum', to='bp_cupid.BPVerwaltungszeitraum'),
        ),
    ]
