# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0061_student_hat_seminar_besucht'),
    ]

    operations = [
        migrations.AddField(
            model_name='praxis',
            name='hat_bp_urkunde_erhalten',
            field=models.BooleanField(verbose_name='hat BP-Urkunde erhalten', default=False),
        ),
        migrations.AddField(
            model_name='praxis',
            name='hat_pj_urkunde_erhalten',
            field=models.BooleanField(verbose_name='hat PJ-Urkunde erhalten', default=False),
        ),
    ]
