# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('bp_cupid', '0045_vergroessert_zeichenbegrenzung_der_landkreise'),
    ]

    operations = [
        migrations.CreateModel(
            name='Abrechnungsdetail',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, verbose_name='ID', serialize=False)),
                ('erstellt', models.DateField(null=True, verbose_name='Rechnung erstellt am', blank=True)),
                ('eingegangen', models.DateField(null=True, verbose_name='Rechnung eingegangen am', blank=True)),
                ('weiterleitung_an_df', models.DateField(null=True, verbose_name='Rechnung weitergeleitet an DF am', blank=True)),
                ('buchung_erfolgt', models.DateField(null=True, verbose_name='Buchung ist erfolgt am', blank=True)),
                ('erinnerung_an_la', models.DateField(null=True, verbose_name='LA wurde nochmal erinnert am', blank=True)),
                ('praxis', models.ForeignKey(to='bp_cupid.Praxis', related_name='abrechnungsdetail')),
                ('verwaltungszeitraum', models.ForeignKey(to='bp_cupid.Verwaltungszeitraum', related_name='abrechnungsdetail')),
            ],
            options={
                'verbose_name': 'Abrechnungsdetail',
                'verbose_name_plural': 'Abrechnungsdetails',
            },
        ),
        migrations.CreateModel(
            name='HistoricalAbrechnungsdetail',
            fields=[
                ('id', models.IntegerField(db_index=True, verbose_name='ID', auto_created=True, blank=True)),
                ('erstellt', models.DateField(null=True, verbose_name='Rechnung erstellt am', blank=True)),
                ('eingegangen', models.DateField(null=True, verbose_name='Rechnung eingegangen am', blank=True)),
                ('weiterleitung_an_df', models.DateField(null=True, verbose_name='Rechnung weitergeleitet an DF am', blank=True)),
                ('buchung_erfolgt', models.DateField(null=True, verbose_name='Buchung ist erfolgt am', blank=True)),
                ('erinnerung_an_la', models.DateField(null=True, verbose_name='LA wurde nochmal erinnert am', blank=True)),
                ('history_id', models.AutoField(primary_key=True, serialize=False)),
                ('history_date', models.DateTimeField()),
                ('history_type', models.CharField(choices=[('+', 'Created'), ('~', 'Changed'), ('-', 'Deleted')], max_length=1)),
                ('history_user', models.ForeignKey(null=True, related_name='+', to=settings.AUTH_USER_MODEL, on_delete=django.db.models.deletion.SET_NULL)),
                ('praxis', models.ForeignKey(null=True, related_name='+', to='bp_cupid.Praxis', blank=True, db_constraint=False, on_delete=django.db.models.deletion.DO_NOTHING)),
                ('verwaltungszeitraum', models.ForeignKey(null=True, related_name='+', to='bp_cupid.Verwaltungszeitraum', blank=True, db_constraint=False, on_delete=django.db.models.deletion.DO_NOTHING)),
            ],
            options={
                'ordering': ('-history_date', '-history_id'),
                'verbose_name': 'historical Abrechnungsdetail',
                'get_latest_by': 'history_date',
            },
        ),
        migrations.AlterUniqueTogether(
            name='abrechnungsdetail',
            unique_together=set([('verwaltungszeitraum', 'praxis')]),
        ),
    ]
