# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0058_student_noten'),
    ]

    operations = [
        migrations.AddField(
            model_name='praxis',
            name='bundeswehr',
            field=models.BooleanField(verbose_name='Gehört zur Bundeswehr', default=False),
        ),
    ]
