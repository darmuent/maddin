# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import django.core.validators


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('bp_cupid', '0040_remove_pj_platz'),
    ]

    operations = [
        migrations.CreateModel(
            name='Evaluation',
            fields=[
                ('platz', models.OneToOneField(to='bp_cupid.Platz', serialize=False, related_name='evaluation', primary_key=True)),
                ('datum', models.DateField(verbose_name='aktuelles Datum', auto_now_add=True)),
                ('positiv', models.TextField(default='', help_text='Was war positiv?', blank=True)),
                ('negativ', models.TextField(default='', help_text='Was war negativ?', blank=True)),
                ('note_lehrarztfaehigkeit', models.DecimalField(max_digits=2, default=0, verbose_name='Lehrarztfähigkeit des Arztes', help_text='Note als Zahl (z.B. 1 oder 2,5)', decimal_places=1)),
                ('zufriedenheit', models.IntegerField(default=3, verbose_name='Zufriedenheit mit dem Praktikum', choices=[(1, 'sehr zufrieden'), (2, 'zufrieden'), (3, 'mittelmäßig'), (4, 'unzufrieden'), (5, 'sehr unzufrieden')])),
                ('note_praktikum', models.DecimalField(max_digits=2, default=0, verbose_name='Note für das Praktikum', help_text='Note als Zahl (z.B. 1 oder 2,5)', decimal_places=1)),
                ('sonstige_anmerkungen', models.TextField(default='', verbose_name='Sonstige Anmerkungen', blank=True)),
                ('erfahrungen_logbuch', models.TextField(default='', verbose_name='Erfahrungen mit dem Logbuch', blank=True)),
                ('entsprechung_fragebogen', models.TextField(default='', verbose_name='Interessen = Fragebogen?', help_text='Entspricht der BP-Platz den Interessen wie im Online-Fragebogen angegeben?', blank=True)),
                ('abhoeren_auskultation', models.IntegerField(default=0, verbose_name='Abhören/Auskultation', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_abhoeren_auskultation', models.TextField(default='', verbose_name='Kommentar zu Abhören/Auskultation', blank=True)),
                ('ohr_untersuchen', models.IntegerField(default=0, verbose_name='Ohr untersuchen', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_ohr_untersuchen', models.TextField(default='', verbose_name='Kommentar zu Ohr untersuchen', blank=True)),
                ('reflexe_abklopfen', models.IntegerField(default=0, verbose_name='Reflexe abklopfen', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_reflexe_abklopfen', models.TextField(default='', verbose_name='Kommentar zu Reflexe abklopfen', blank=True)),
                ('bauch_abtasten', models.IntegerField(default=0, verbose_name='Bauch abtasten', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_bauch_abtasten', models.TextField(default='', verbose_name='Kommentar zu Bauch abtasten', blank=True)),
                ('blutdruck_messen', models.IntegerField(default=0, verbose_name='Blutdruck messen', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_blutdruck_messen', models.TextField(default='', verbose_name='Kommentar zu Blutdruck messen', blank=True)),
                ('blut_abnehmen', models.IntegerField(default=0, verbose_name='Blut abnehmen', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_blut_abnehmen', models.TextField(default='', verbose_name='Kommentar zu Blut abnehmen', blank=True)),
                ('blutzucker_messen', models.IntegerField(default=0, verbose_name='Blutzucker messen', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_blutzucker_messen', models.TextField(default='', verbose_name='Kommentar zu Blutzucker messen', blank=True)),
                ('ekg_schreiben', models.IntegerField(default=0, verbose_name='EKG schreiben', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_ekg_schreiben', models.TextField(default='', verbose_name='Kommentar zu EKG schreiben', blank=True)),
                ('ekg_interpretieren', models.IntegerField(default=0, verbose_name='EKG interpretieren', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_ekg_interpretieren', models.TextField(default='', verbose_name='Kommentar zu EKG interpretieren', blank=True)),
                ('laborbefunde_interpretieren', models.IntegerField(default=0, verbose_name='Laborbefunde interpretieren', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_laborbefunde_interpretieren', models.TextField(default='', verbose_name='Kommentar zu Laborbefunde interpretieren', blank=True)),
                ('sonstige_untersuchungstechniken', models.TextField(default='', verbose_name='sonstige Untersuchungstechniken', blank=True)),
                ('impfen', models.IntegerField(default=0, verbose_name='Impfen/Impfberatung', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_impfen', models.TextField(default='', verbose_name='Kommentar zu Impfen/Impfberatung', blank=True)),
                ('spritzen', models.IntegerField(default=0, verbose_name='Spritzen (z.B. IM, IV, B12, Quaddeln, usw.)', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_spritzen', models.TextField(default='', verbose_name='Kommentar zu Spritzen (z.B. IM, IV, B12, Quaddeln, usw.)', blank=True)),
                ('gesundheits_check_up', models.IntegerField(default=0, verbose_name='Gesundheits-Check-Up', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_gesundheits_check_up', models.TextField(default='', verbose_name='Kommentar zu Gesundheits-Check-Up', blank=True)),
                ('hausbesuche_pflegeheim', models.IntegerField(default=0, verbose_name='Hausbesuche/Pflegeheim', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_hausbesuche_pflegeheim', models.TextField(default='', verbose_name='Kommentar zu Hausbesuche/Pflegeheim', blank=True)),
                ('vorbereitung_auf_studenten', models.IntegerField(default=0, verbose_name='Vorbereitung auf Studenten', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_vorbereitung_auf_studenten', models.TextField(default='', verbose_name='Kommentar zu Vorbereitung auf Studenten', blank=True)),
                ('einbindung_praxisalltag', models.IntegerField(default=0, verbose_name='Einbindung ins Praxisteam/in Praxisalltag', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_einbindung_praxisalltag', models.TextField(default='', verbose_name='Kommentar zu Einbindung ins Praxisteam/in Praxisalltag', blank=True)),
                ('praxisklima', models.IntegerField(default=0, verbose_name='Praxisklima', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_praxisklima', models.TextField(default='', verbose_name='Kommentar zu Praxisklima', blank=True)),
                ('eigener_untersuchungsraum', models.IntegerField(default=0, verbose_name='eigener Untersuchungsraum', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_eigener_untersuchungsraum', models.TextField(default='', verbose_name='Kommentar zu eigener Untersuchungsraum', blank=True)),
                ('teilnehmen_an_sprechstunde', models.IntegerField(default=0, verbose_name='anwesend/teilnehmend in/an Sprechstunde/-zimmer', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_teilnehmen_an_sprechstunde', models.TextField(default='', verbose_name='Kommentar zu anwesend/teilnehmend in/an Sprechstunde/-zimmer', blank=True)),
                ('aktiv_mituntersucht', models.IntegerField(default=0, verbose_name='aktiv mituntersucht', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_aktiv_mituntersucht', models.TextField(default='', verbose_name='Kommentar zu aktiv mituntersucht', blank=True)),
                ('selbststaendige_untersuchung', models.IntegerField(default=0, verbose_name='selbstständige Anamnese/Untersuchung', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_selbststaendige_untersuchung', models.TextField(default='', verbose_name='Kommentar zu selbstständige Anamnese/Untersuchung', blank=True)),
                ('zeit_raum_fuer_fragen', models.IntegerField(default=0, verbose_name='Zeit/Raum für Fragen', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_zeit_raum_fuer_fragen', models.TextField(default='', verbose_name='Kommentar zu Zeit/Raum für Fragen', blank=True)),
                ('von_sich_aus_erklaert', models.IntegerField(default=0, verbose_name='von sich aus erklärt', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_von_sich_aus_erklaert', models.TextField(default='', verbose_name='Kommentar zu von sich aus erklärt', blank=True)),
                ('fragen_an_studenten', models.IntegerField(default=0, verbose_name='Fragen an Studenten', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_fragen_an_studenten', models.TextField(default='', verbose_name='Kommentar zu Fragen an Studenten', blank=True)),
                ('vor_nachbesprechung_der_patienten', models.IntegerField(default=0, verbose_name='Vor- & Nachbesprechung der Patienten', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_vor_nachbesprechung_der_patienten', models.TextField(default='', verbose_name='Kommentar zu Vor- & Nachbesprechung der Patienten', blank=True)),
                ('motivation', models.IntegerField(default=0, verbose_name='Motivation des/der LA/LÄ', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_motivation', models.TextField(default='', verbose_name='Kommentar zu Motivation des/der LA/LÄ', blank=True)),
                ('lerneffekt', models.IntegerField(default=0, verbose_name='Lerneffekt', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_lerneffekt', models.TextField(default='', verbose_name='Kommentar zu Lerneffekt', blank=True)),
                ('feedback_vom_arzt', models.IntegerField(default=0, verbose_name='Feedback vom Arzt', choices=[(1, 'ja'), (-1, 'nein'), (0, 'keine Angabe')])),
                ('kommentar_feedback_vom_arzt', models.TextField(default='', verbose_name='Kommentar zu Feedback vom Arzt', blank=True)),
                ('veraenderungswuensche', models.TextField(default='', verbose_name='Veränderungswünsche', blank=True)),
                ('sonstiges_positiv', models.TextField(default='', verbose_name='Sonstiges (positiv)', blank=True)),
                ('sonstiges_negativ', models.TextField(default='', verbose_name='Sonstiges (negativ)', blank=True)),
                ('sonstiges_neutral', models.TextField(default='', verbose_name='Sonstiges (neutral)', blank=True)),
                ('gesamturteil', models.TextField(default='', verbose_name='Gesamturteil', blank=True)),
                ('eval_user', models.ForeignKey(to=settings.AUTH_USER_MODEL, verbose_name='evaluierender Benutzer', related_name='evaluationen')),
            ],
            options={
                'verbose_name_plural': 'Evaluationen',
                'verbose_name': 'Evaluation',
            },
        ),
    ]
