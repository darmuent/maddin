# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0073_evaluation_und_kleine_sachen_zu_bpplatz'),
    ]

    operations = [
        # Wir löschen HistoricalPlatz einfach und legen es danach neu an. Soo
        # wichtig war's nun auch wieder nicht.
        #
        migrations.DeleteModel(
            name='HistoricalPlatz',
        ),
        # HistoricalPlatz → HistoricalBPPlatz
        #
        # Das hier wurde automatisch generiert:
        #
        # migrations.CreateModel(
        #     name='HistoricalBPPlatz',
        #     fields=[
        #         ('kommentar', models.TextField(blank=True, default='')),
        #         ('manuell', models.BooleanField(default=False, help_text='Wenn aktiviert, dann wird der Platz bei der automatischen Platzvergabe nicht gelöscht.')),
        #         ('history_id', models.AutoField(primary_key=True, serialize=False)),
        #         ('history_date', models.DateTimeField()),
        #         ('history_change_reason', models.CharField(max_length=100, null=True)),
        #         ('history_type', models.CharField(max_length=1, choices=[('+', 'Created'), ('~', 'Changed'), ('-', 'Deleted')])),
        #     ],
        #     options={
        #         'verbose_name': 'historical BP-Platz',
        #         'ordering': ('-history_date', '-history_id'),
        #         'get_latest_by': 'history_date',
        #     },
        # ),
        # migrations.RemoveField(
        #     model_name='historicalplatz',
        #     name='bp_zeitraum',
        # ),
        # migrations.RemoveField(
        #     model_name='historicalplatz',
        #     name='history_user',
        # ),
        # migrations.RemoveField(
        #     model_name='historicalplatz',
        #     name='praxis',
        # ),
        # migrations.RemoveField(
        #     model_name='historicalplatz',
        #     name='student',
        # ),
        # migrations.AddField(
        #     model_name='historicalbpplatz',
        #     name='bp_zeitraum',
        #     field=models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.BPZeitraum', db_constraint=False),
        # ),
        # migrations.AddField(
        #     model_name='historicalbpplatz',
        #     name='history_user',
        #     field=models.ForeignKey(null=True, related_name='+', on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL),
        # ),
        # migrations.AddField(
        #     model_name='historicalbpplatz',
        #     name='praxis',
        #     field=models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.Praxis', db_constraint=False),
        # ),
        # migrations.AddField(
        #     model_name='historicalbpplatz',
        #     name='student',
        #     field=models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.Student', db_constraint=False),
        # ),

        # Und das hier hab ich versucht, aber es mündete immer in
        # django.db.utils.OperationalError: near "AUTOINCREMENT": syntax error
        #
        # migrations.RenameModel(
        #     old_name='HistoricalPlatz',
        #     new_name='HistoricalBPPlatz',
        # ),
        # migrations.AlterField(
        #     model_name='HistoricalBPPlatz',
        #     name='student',
        #     field=models.OneToOneField(
        #         primary_key=True,
        #         related_name='bpplatz',
        #         to='bp_cupid.Student'
        #     ),
        # ),
        # migrations.AlterField(
        #     model_name='HistoricalBPPlatz',
        #     name='praxis',
        #     field=models.ForeignKey(
        #         related_name='bpplatz_related',
        #         to='bp_cupid.Praxis'
        #     ),
        # ),
        # migrations.AlterModelOptions(
        #     name='HistoricalBPPlatz',
        #     options={
        #         'verbose_name': 'historical BP-Platz',
        #         'ordering': ('-history_date', '-history_id'),
        #         'get_latest_by': 'history_date',
        #     },
        # ),
    ]
