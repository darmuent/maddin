# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0080_pjplatz'),
    ]

    operations = [
        migrations.AddField(
            model_name='pjzeitraum',
            name='ueberlappende',
            field=models.ManyToManyField(verbose_name='Überlappende PJ-Zeiträume', blank=True, db_table='ueberlappende_pj_zeitraeume', related_name='_pjzeitraum_ueberlappende_+', to='bp_cupid.PJZeitraum'),
        ),
        migrations.AddField(
            model_name='pjzeitraum',
            name='ueberlappende_bp',
            field=models.ManyToManyField(verbose_name='Überlappende BP-Zeiträume', blank=True, db_table='ueberlappende_bp_pj', related_name='ueberlappende_pj', to='bp_cupid.BPZeitraum'),
        ),
        migrations.AddField(
            model_name='praxis',
            name='belegte_pj_zeitraeume',
            field=models.ManyToManyField(verbose_name='belegte PJ-Zeiträume', blank=True, db_table='praxis_pj_zeitraum_belegt', related_name='pj_praxen_belegt', to='bp_cupid.PJZeitraum'),
        ),
        migrations.AddField(
            model_name='praxis',
            name='freie_pj_zeitraeume',
            field=models.ManyToManyField(verbose_name='freie PJ-Zeiträume', blank=True, db_table='praxis_pj_zeitraum_frei', related_name='pj_praxen_frei', to='bp_cupid.PJZeitraum'),
        ),
        migrations.AddField(
            model_name='praxis',
            name='pj_zeitraeume',
            field=models.ManyToManyField(verbose_name='PJ-Zeiträume', blank=True, db_table='praxis_pj_zeitraum', related_name='pj_praxen', to='bp_cupid.PJZeitraum'),
        ),
    ]
