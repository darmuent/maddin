# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0059_praxis_bundeswehr'),
    ]

    operations = [
        migrations.RenameField(
            model_name='historicalstudent',
            old_name='hohe_duene',
            new_name='bundeswehr',
        ),
        migrations.RenameField(
            model_name='historicalstudent',
            old_name='gewichtung_hohe_duene',
            new_name='gewichtung_bundeswehr',
        ),
        migrations.RenameField(
            model_name='student',
            old_name='hohe_duene',
            new_name='bundeswehr',
        ),
        migrations.RenameField(
            model_name='student',
            old_name='gewichtung_hohe_duene',
            new_name='gewichtung_bundeswehr',
        ),
        migrations.AlterField(
            model_name='historicalstudent',
            name='bundeswehr',
            field=models.BooleanField(verbose_name='Bundeswehr', default=False),
        ),
        migrations.AlterField(
            model_name='historicalstudent',
            name='gewichtung_bundeswehr',
            field=models.IntegerField(verbose_name='G Bundeswehr', default=0),
        ),
        migrations.AlterField(
            model_name='student',
            name='bundeswehr',
            field=models.BooleanField(verbose_name='Bundeswehr', default=False),
        ),
        migrations.AlterField(
            model_name='student',
            name='gewichtung_bundeswehr',
            field=models.IntegerField(verbose_name='G Bundeswehr', default=0),
        ),
    ]
