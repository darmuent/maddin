# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0072_platzbegrenzung_zu_bpplatzbegrenzung'),
    ]

    operations = [
        # help_text von BPVerwaltungszeitraum.plaetze_fuer_studenten_einsehbar
        migrations.AlterField(
            model_name='bpverwaltungszeitraum',
            name='plaetze_fuer_studenten_einsehbar',
            field=models.BooleanField(
                verbose_name='BP-Plätze sind für Studenten einsehbar',
                default=False,
                help_text='Wenn aktiviert, dann werden die zugewiesenen BP-Plätze auf der Startseite der Studenten angezeigt.'
            ),
        ),

        # Evaluation.platz → Evaluation.bp_platz
        #
        # migrations.RemoveField(
        #     model_name='evaluation',
        #     name='platz',
        # ),
        # migrations.AddField(
        #     model_name='evaluation',
        #     name='bp_platz',
        #     field=models.OneToOneField(primary_key=True, default=0, serialize=False, related_name='evaluation', to='bp_cupid.BPPlatz'),
        #     preserve_default=False,
        # ),

        migrations.AlterField(
            model_name='Evaluation',
            name='platz',
            field=models.OneToOneField(
                primary_key=True,
                related_name='evaluation',
                to='bp_cupid.BPPlatz'
            ),
        ),
        migrations.RenameField(
            model_name='Evaluation',
            old_name='platz',
            new_name='bp_platz',
        ),
    ]
