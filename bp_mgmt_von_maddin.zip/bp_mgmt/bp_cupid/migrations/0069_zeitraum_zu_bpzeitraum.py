# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0068_zeitraum_fk_to_bpblock_add_verbose_name'),
    ]

    operations = [
        # Alles für Zeitraum an sich:

        # migrations.CreateModel(
        #     name='BPZeitraum',
        #     fields=[
        #         ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
        #         ('anfang', models.DateField()),
        #         ('ende', models.DateField()),
        #         ('bp_block', models.ForeignKey(verbose_name='BP-Block', related_name='bp_zeitraeume', to='bp_cupid.BPBlock')),
        #         ('ueberlappende', models.ManyToManyField(verbose_name='Überlappende Zeiträume', blank=True, db_table='ueberlappende_bp_zeitraeume', related_name='_bpzeitraum_ueberlappende_+', to='bp_cupid.BPZeitraum')),
        #     ],
        #     options={
        #         'verbose_name': 'Zeitraum',
        #         'verbose_name_plural': 'Zeiträume',
        #         'ordering': ['anfang'],
        #     },
        # ),
        # migrations.RemoveField(
        #     model_name='zeitraum',
        #     name='bp_block',
        # ),
        # migrations.RemoveField(
        #     model_name='zeitraum',
        #     name='ueberlappende',
        # ),

        migrations.RemoveField(
            model_name='Zeitraum',
            name='ueberlappende',
        ),
        migrations.RenameModel(
            old_name='Zeitraum',
            new_name='BPZeitraum',
        ),
        migrations.AlterModelOptions(
            name='BPZeitraum',
            options={
                'verbose_name': 'BP-Zeitraum',
                'verbose_name_plural': 'BP-Zeiträume',
                'ordering': ['anfang'],
            },
        ),
        migrations.AddField(
            model_name='BPZeitraum',
            name='ueberlappende',
            field=models.ManyToManyField(
                verbose_name='Überlappende BP-Zeiträume',
                blank=True,
                db_table='ueberlappende_bp_zeitraeume',
                related_name='_zeitraum_ueberlappende_+',
                to='bp_cupid.BPZeitraum'
            ),
        ),

        # Platz → BPZeitraum

        # migrations.AlterModelOptions(
        #     name='platz',
        #     options={'verbose_name': 'Platz', 'verbose_name_plural': 'Plätze', 'ordering': ['bp_zeitraum']},
        # ),
        # migrations.AlterUniqueTogether(
        #     name='platz',
        #     unique_together=set([('praxis', 'bp_zeitraum')]),
        # ),
        # migrations.RemoveField(
        #     model_name='platz',
        #     name='zeitraum',
        # ),
        # migrations.AddField(
        #     model_name='platz',
        #     name='bp_zeitraum',
        #     field=models.ForeignKey(default=0, related_name='plaetze', to='bp_cupid.BPZeitraum'),
        #     preserve_default=False,
        # ),

        migrations.AlterField(
            model_name='Platz',
            name='zeitraum',
            field=models.ForeignKey(
                related_name='bp_plaetze',
                on_delete=django.db.models.deletion.DO_NOTHING,
                to='bp_cupid.BPZeitraum',
            ),
        ),
        migrations.RenameField(
            model_name='Platz',
            old_name='zeitraum',
            new_name='bp_zeitraum',
        ),

        # HistoricalPlatz → BPZeitraum

        # migrations.RemoveField(
        #     model_name='historicalplatz',
        #     name='zeitraum',
        # ),
        # migrations.AddField(
        #     model_name='historicalplatz',
        #     name='bp_zeitraum',
        #     field=models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.BPZeitraum', db_constraint=False),
        # ),

        migrations.AlterField(
            model_name='HistoricalPlatz',
            name='zeitraum',
            field=models.ForeignKey(
                related_name='bp_plaetze',
                on_delete=django.db.models.deletion.DO_NOTHING,
                to='bp_cupid.BPZeitraum',
            ),
        ),
        migrations.RenameField(
            model_name='HistoricalPlatz',
            old_name='zeitraum',
            new_name='bp_zeitraum',
        ),

        # Praxis → BPZeitraum

        # migrations.RemoveField(
        #     model_name='praxis',
        #     name='belegte_zeitraeume',
        # ),
        # migrations.RemoveField(
        #     model_name='praxis',
        #     name='freie_zeitraeume',
        # ),
        # migrations.RemoveField(
        #     model_name='praxis',
        #     name='zeitraeume',
        # ),
        # migrations.AddField(
        #     model_name='praxis',
        #     name='belegte_bp_zeitraeume',
        #     field=models.ManyToManyField(verbose_name='belegte BP-Zeiträume', blank=True, db_table='praxis_bp_zeitraum_belegt', related_name='praxen_belegt', to='bp_cupid.BPZeitraum'),
        # ),
        # migrations.AddField(
        #     model_name='praxis',
        #     name='bp_zeitraeume',
        #     field=models.ManyToManyField(verbose_name='BP-Zeiträume', blank=True, db_table='praxis_bp_zeitraum', related_name='praxen', to='bp_cupid.BPZeitraum'),
        # ),
        # migrations.AddField(
        #     model_name='praxis',
        #     name='freie_bp_zeitraeume',
        #     field=models.ManyToManyField(verbose_name='freie BP-Zeiträume', blank=True, db_table='praxis_bp_zeitraum_frei', related_name='praxen_frei', to='bp_cupid.BPZeitraum'),
        # ),

        migrations.AlterField(
            model_name='Praxis',
            name='belegte_zeitraeume',
            field=models.ManyToManyField(
                verbose_name='belegte BP-Zeiträume',
                blank=True,
                db_table='praxis_bp_zeitraum_belegt',
                related_name='bp_praxen_belegt',
                to='bp_cupid.BPZeitraum'
            ),
        ),
        migrations.RenameField(
            model_name='Praxis',
            old_name='belegte_zeitraeume',
            new_name='belegte_bp_zeitraeume',
        ),
        migrations.AlterField(
            model_name='Praxis',
            name='freie_zeitraeume',
            field=models.ManyToManyField(
                verbose_name='freie BP-Zeiträume',
                blank=True,
                db_table='praxis_bp_zeitraum_frei',
                related_name='bp_praxen_frei',
                to='bp_cupid.BPZeitraum'
            ),
        ),
        migrations.RenameField(
            model_name='Praxis',
            old_name='freie_zeitraeume',
            new_name='freie_bp_zeitraeume',
        ),
        migrations.AlterField(
            model_name='Praxis',
            name='zeitraeume',
            field=models.ManyToManyField(
                verbose_name='BP-Zeiträume',
                blank=True,
                db_table='praxis_bp_zeitraum',
                related_name='bp_praxen',
                to='bp_cupid.BPZeitraum'
            ),
        ),
        migrations.RenameField(
            model_name='Praxis',
            old_name='zeitraeume',
            new_name='bp_zeitraeume',
        ),

        # migrations.DeleteModel(
        #     name='Zeitraum',
        # ),
    ]
