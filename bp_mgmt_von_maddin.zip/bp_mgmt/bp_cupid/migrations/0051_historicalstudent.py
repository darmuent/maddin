# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion
import django.core.validators
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('bp_cupid', '0050_block_kapazitaet'),
    ]

    operations = [
        migrations.CreateModel(
            name='HistoricalStudent',
            fields=[
                ('id', models.IntegerField(verbose_name='ID', blank=True, db_index=True, auto_created=True)),
                ('mat_nr', models.IntegerField(verbose_name='Matrikelnummer', db_index=True)),
                ('name', models.CharField(verbose_name='Name', max_length=50, blank=True, default='')),
                ('vorname', models.CharField(verbose_name='Vorname', max_length=100, blank=True, default='')),
                ('email', models.EmailField(verbose_name='E-Mail', max_length=254, default='')),
                ('weiblich', models.BooleanField(default=False)),
                ('telefonnummer', models.CharField(verbose_name='Telefonnummer', max_length=15, blank=True, default='', validators=[django.core.validators.RegexValidator(regex='^\\+?1?\\d{9,15}$', message="Telefonnummer muss von folgendem Format sein: '+999999999'. Es sind bis zu 15 Ziffern erlaubt.")])),
                ('hat_fragebogen_ausgefuellt', models.BooleanField(verbose_name='hat Fragebogen ausgefüllt', default=False)),
                ('kinder', models.BooleanField(verbose_name='Kinder', default=False)),
                ('gewichtung_kinder', models.IntegerField(verbose_name='G Kinder', default=0)),
                ('sono', models.BooleanField(verbose_name='Sono', default=False)),
                ('gewichtung_sono', models.IntegerField(verbose_name='G Sono', default=0)),
                ('sport', models.BooleanField(verbose_name='Sport', default=False)),
                ('gewichtung_sport', models.IntegerField(verbose_name='G Sport', default=0)),
                ('kompl', models.BooleanField(verbose_name='Kompl', default=False)),
                ('gewichtung_kompl', models.IntegerField(verbose_name='G Kompl', default=0)),
                ('hohe_duene', models.BooleanField(verbose_name='H. Düne', default=False)),
                ('gewichtung_hohe_duene', models.IntegerField(verbose_name='G H. Düne', default=0)),
                ('entfernte_praxis_wenn_unterkunft', models.BooleanField(verbose_name='entf. Praxis', default=False)),
                ('fs_und_fahrzeug', models.BooleanField(verbose_name='FS+Auto', default=False)),
                ('priv_unterkunft', models.BooleanField(verbose_name='priv. Unterkunft', default=False)),
                ('besondere_praxiskriterien', models.TextField(verbose_name='besondere Praxiskriterien', blank=True, default='')),
                ('adresse_priv_unterkunft', models.TextField(verbose_name='Ort+PLZ', blank=True, default='')),
                ('sonstiges', models.TextField(verbose_name='Sonstiges', blank=True, default='')),
                ('extern', models.BooleanField(verbose_name='macht BP extern', default=False)),
                ('history_id', models.AutoField(primary_key=True, serialize=False)),
                ('history_date', models.DateTimeField()),
                ('history_type', models.CharField(max_length=1, choices=[('+', 'Created'), ('~', 'Changed'), ('-', 'Deleted')])),
                ('history_user', models.ForeignKey(null=True, related_name='+', on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
                ('user', models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to=settings.AUTH_USER_MODEL, db_constraint=False)),
                ('verwaltungszeitraum', models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.Verwaltungszeitraum', db_constraint=False)),
            ],
            options={
                'verbose_name': 'historical Student',
                'ordering': ('-history_date', '-history_id'),
                'get_latest_by': 'history_date',
            },
        ),
    ]
