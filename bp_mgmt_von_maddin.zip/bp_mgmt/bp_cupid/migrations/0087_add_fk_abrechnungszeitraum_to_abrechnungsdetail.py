# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0086_erzeuge_standardabrechnungszeitraeume'),
    ]

    operations = [
        migrations.AddField(
            model_name='abrechnungsdetail',
            name='abrechnungszeitraum',
            field=models.ForeignKey(null=True, related_name='abrechnungsdetail', to='bp_cupid.Abrechnungszeitraum'),
        ),
        migrations.AddField(
            model_name='historicalabrechnungsdetail',
            name='abrechnungszeitraum',
            field=models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.Abrechnungszeitraum', db_constraint=False),
        ),
    ]
