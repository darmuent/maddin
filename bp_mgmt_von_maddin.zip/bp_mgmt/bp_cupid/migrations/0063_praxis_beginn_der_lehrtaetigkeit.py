# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0062_praxen_urkunden'),
    ]

    operations = [
        migrations.AddField(
            model_name='praxis',
            name='beginn_bp_lehrtaetigkeit',
            field=models.DateField(verbose_name='Beginn der BP-Lehrtätigkeit', blank=True, null=True, help_text='Wird als Datum gespeichert. Zum Beispiel 30.09.2016'),
        ),
        migrations.AddField(
            model_name='praxis',
            name='beginn_pj_lehrtaetigkeit',
            field=models.DateField(verbose_name='Beginn der PJ-Lehrtätigkeit', blank=True, null=True, help_text='Wird als Datum gespeichert. Zum Beispiel 30.09.2016'),
        ),
    ]
