# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations
from django.contrib.sites.models import Site

def change_default_site(apps, schema_editor):
    site, created = Site.objects.get_or_create(id=1)
    site.name = 'BP Cupid'
    site.domain = 'allgemeinmedizin-bp.med.uni-rostock.de'
    site.save()


def reset_default_site(apps, schema_editor):
    site = Site.objects.get(id=1)
    site.name = 'example.com'
    site.save()


class Migration(migrations.Migration):

    dependencies = [
        ('sites', '0001_initial'),
        ('bp_cupid', '0032_student_user_blank'),
    ]

    operations = [
        migrations.RunPython(
            change_default_site,
            reverse_code=reset_default_site
        ),
    ]
