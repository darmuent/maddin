# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0047_kosmetische_aenderungen'),
    ]

    operations = [
        migrations.AddField(
            model_name='verwaltungszeitraum',
            name='plaetze_fuer_studenten_einsehbar',
            field=models.BooleanField(verbose_name='Plätze sind für Studenten einsehbar', default=False, help_text='Wenn aktiviert, dann werden die zugewiesenen Plätze auf der Startseite der Studenten angezeigt.'),
        ),
    ]
