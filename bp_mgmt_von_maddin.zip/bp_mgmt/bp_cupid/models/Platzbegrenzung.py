"""
Eine Platzbegrenzung für das BP.
"""

from django.db import models
from django.core.validators import MinValueValidator

from . import (
    Praxis,
    BPVerwaltungszeitraum,
)


class BPPlatzbegrenzung(models.Model):
    """
    Eine Platzbegrenzung für das BP gibt an, wieviele BP-Plätze eine Praxis in
    einem Verwaltungszeitraum maximal haben möchte.

    Durch die Fremdschlüssel haben wir den Vorteil, dass das Nichtvorhandensein
    einer Begrenzung durch das Nichtvorhandensein der Relation gelöst wird.
    """
    bp_verwaltungszeitraum = models.ForeignKey(
        BPVerwaltungszeitraum,
        related_name='bpplatzbegrenzung',
    )
    praxis = models.ForeignKey(
        Praxis,
        related_name='bpplatzbegrenzung',
    )
    anzahl = models.IntegerField(
        verbose_name='max. Anzahl BP-Plätze',
        validators=[MinValueValidator(0, 'Anzahl darf nicht negativ sein.')],
    )

    class Meta:
        verbose_name = 'BP-Platzbegrenzung'
        verbose_name_plural = 'BP-Platzbegrenzungen'
        unique_together = ('bp_verwaltungszeitraum', 'praxis')

    def __str__(self):
        return 'maximal {anzahl} BP-Plätze für {praxis} in {verwzr}'.format(
            praxis=self.praxis,
            verwzr=self.bp_verwaltungszeitraum,
            anzahl=self.anzahl,
        )
