"""
Ein Student.
"""

from django.conf import settings
from django.core.exceptions import ValidationError, ObjectDoesNotExist
from django.core.urlresolvers import reverse
from django.db import models
from django.db.models import Q
from simple_history.models import HistoricalRecords

from . import (
    Landkreis,
    BPVerwaltungszeitraum,
)
from ..validators import telefon_regex, validate_note


class StudentManager(models.Manager):
    """
    Besondere Funktionen für alle Studenten.
    """
    def frei(self):
        """
        Gibt alle freien Studenten zurück.

        Ein Student hat einen BP-Platz oder nicht. Wenn dieser Student keinen
        BP-Platz hat, absolviert er/sie das BP extern oder nicht.

        Nur wenn er/sie keinen BP-Platz hat und das BP nicht extern absolviert,
        ist er/sie frei.
        """
        return self.filter(
            Q(bpplatz__isnull=True) & Q(extern=False)
        )


class Student(models.Model):
    """
    Ein Student ist einem BP-Verwaltungszeitraum zugeordnet. Ein Student hat
    persönliche Daten wie Matrikelnummer, Name, E-Mail-Adresse und
    Weiblichkeit.  Dazu kommen noch die relevanten Daten für das Blockpraktikum
    (Kinder, Sono, etc.). Weiterhin darf sich ein Student bevorzugte Landkreise
    aussuchen.
    """
    # Relationen
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        blank=True,
        null=True,
    )
    bp_verwaltungszeitraum = models.ForeignKey(
        BPVerwaltungszeitraum,
        verbose_name='BP-Verwaltungszeitraum',
    )
    # Die gehören eigentlich weiter unten hin, aber es ist auch eine Relation:
    landkreise = models.ManyToManyField(
        Landkreis,
        db_table="student_landkreis",
        blank=True,
    )
    bevorzugte_praxen = models.ManyToManyField(
        'bp_cupid.Praxis',
        db_table='bevorzugte_praxen',
        related_name='bevorzugte_praxen',
        blank=True,
        verbose_name='bevorzugte Praxen',
    )
    abgeneigte_praxen = models.ManyToManyField(
        'bp_cupid.Praxis',
        db_table='abgeneigte_praxen',
        related_name='abgeneigte_praxen',
        blank=True,
        verbose_name='abgeneigte Praxen',
    )

    """
    Wenn wir alle freien Studenten haben möchten, dann könnten wir das entweder
    über eine classmethod lösen oder den Manager überschreiben. Letzteres wird
    empfohlen und wirkt richtig. Siehe auch den obigen StudentManager.
    """
    objects = StudentManager()

    # Änderungsgeschichte:
    history = HistoricalRecords()

    # persönliche Daten:
    mat_nr = models.IntegerField(
        unique=True,
        verbose_name='Matrikelnummer',
    )
    name = models.CharField(
        max_length=50,
        verbose_name='Name',
        default='',
        blank=True,
    )
    vorname = models.CharField(
        max_length=100,
        verbose_name='Vorname',
        default='',
        blank=True,
    )
    email = models.EmailField(
        verbose_name='E-Mail',
        default='',
    )
    weiblich = models.BooleanField(
        default=False,
    )
    telefonnummer = models.CharField(
        max_length=15,
        default='',
        validators=[telefon_regex],
        verbose_name='Telefonnummer',
        blank=True,
    )
    hat_fragebogen_ausgefuellt = models.BooleanField(
        default=False,
        verbose_name='hat Fragebogen ausgefüllt',
    )
    hat_seminar_besucht = models.BooleanField(
        default=False,
        verbose_name='hat Seminar besucht',
    )

    # BP Vorlieben:
    kinder = models.BooleanField(
        verbose_name='Kinder',
        default=False,
    )
    gewichtung_kinder = models.IntegerField(
        default=0,
        verbose_name='G Kinder',
    )
    sono = models.BooleanField(
        verbose_name='Sono',
        default=False,
    )
    gewichtung_sono = models.IntegerField(
        default=0,
        verbose_name='G Sono',
    )
    sport = models.BooleanField(
        verbose_name='Sport',
        default=False,
    )
    gewichtung_sport = models.IntegerField(
        default=0,
        verbose_name='G Sport',
    )
    kompl = models.BooleanField(
        verbose_name='Kompl',
        default=False,
    )
    gewichtung_kompl = models.IntegerField(
        default=0,
        verbose_name='G Kompl',
    )
    bundeswehr = models.BooleanField(
        verbose_name='Bundeswehr',
        default=False,
    )
    gewichtung_bundeswehr = models.IntegerField(
        default=0,
        verbose_name='G Bundeswehr',
    )
    entfernte_praxis_wenn_unterkunft = models.BooleanField(
        verbose_name='entf. Praxis',
        default=False,
    )
    fs_und_fahrzeug = models.BooleanField(
        verbose_name='FS+Auto',
        default=False,
    )
    priv_unterkunft = models.BooleanField(
        verbose_name='priv. Unterkunft',
        default=False
    )
    besondere_praxiskriterien = models.TextField(
        verbose_name='besondere Praxiskriterien',
        default='',
        blank=True,
    )
    adresse_priv_unterkunft = models.TextField(
        verbose_name='Ort+PLZ',
        default='',
        blank=True
    )
    sonstiges = models.TextField(
        verbose_name='Sonstiges',
        default='',
        blank=True
    )
    extern = models.BooleanField(
        default=False,
        verbose_name='macht BP extern',
    )
    interne_notizen = models.TextField(
        verbose_name='interne Notizen',
        default='',
        blank=True
    )
    ist_haertefall = models.BooleanField(
        verbose_name='ist Härtefall',
        default=False,
        help_text=(
            'Wenn aktiv, dann wird der/die Studierende vorrangig an eine '
            'Praxis aus Rostock verteilt.'
        ),
    )
    note_bp = models.DecimalField(
        default=0,
        max_digits=2,
        decimal_places=1,
        verbose_name='Note für das Blockpraktikum',
        help_text='Note als Zahl (z.B. 1 oder 2,5)',
        validators=[validate_note],
    )
    note_klausur = models.DecimalField(
        default=0,
        max_digits=2,
        decimal_places=1,
        verbose_name='Klausurnote',
        help_text='Note als Zahl (z.B. 1 oder 2,5)',
        validators=[validate_note],
    )

    def gewaehlte_landkreise(self):
        """
        Wählt alle gewählten Landkreise, sortiert sie und gibt sie umgebrochen
        aus.
        """
        lks = self.landkreise.all()
        lks = sorted(map(str, lks))
        return '<br />'.join(lks)
    gewaehlte_landkreise.short_description = 'Landkreise'
    gewaehlte_landkreise.allow_tags = True

    def anzahl_landkreise(self):
        return self.landkreise.count()
    anzahl_landkreise.short_description = '#LK'

    def sortierte_gewichte(self):
        """
        Gibt die Gewichte zu den einzelnen Praxen nach Wert sortiert zurück.
        """
        return self.gewichte.order_by('-wert')

    def hat_bp_platz(self):
        try:
            return bool(self.bpplatz)
        except ObjectDoesNotExist:
            return False

    def clean(self):
        if self.hat_bp_platz() and self.extern:
            raise ValidationError(
                'Ein Student darf nicht einen BP-Platz haben und gleichzeitig '
                'das BP extern absolvieren.'
            )

    class Meta:
        verbose_name = 'Student'
        verbose_name_plural = 'Studenten'
        ordering = ['name', 'mat_nr']

    def get_absolute_url(self):
        return reverse('bp_cupid:student', args=[str(self.mat_nr)])

    @property
    def voller_name(self):
        return '{} {}'.format(self.vorname, self.name)

    @property
    def kurzer_name(self):
        if self.vorname and self.name:
            vorname_initial = self.vorname[0]
            kn = '{}. {}'.format(vorname_initial, self.name)
        else:
            kn = str(self.mat_nr)
        return kn

    def __str__(self):
        return '{} {} ({})'.format(self.vorname, self.name, self.mat_nr)
