"""
Ein Zeitraum.
"""

from django.core.exceptions import ValidationError
from django.core.urlresolvers import reverse
from django.db import models
from django.db.models import Q

from . import (
    BPBlock,
    PJBlock,
)


class Zeitraum(models.Model):
    class Meta:
        abstract = True

    anfang = models.DateField()
    ende = models.DateField()

    def clean(self):
        if self.anfang > self.ende:
            raise ValidationError('Das Ende darf nicht vor dem Anfang sein.')

    def __str__(self):
        return '{} - {} ({})'.format(self.anfang, self.ende, self.id)

    @property
    def display(self):
        return '{:%d.%m.%Y} – {:%d.%m.%Y}'.format(self.anfang, self.ende)

    @property
    def short_display(self):
        return '{:%d.%m.} – {:%d.%m.}'.format(self.anfang, self.ende)

    @property
    def zeitspanne(self):
        delta = self.ende - self.anfang
        return delta.days + 1

    def ueberlappende_bp_zeitraeume(self):
        """
        Gibt alle BP-Zeiträume zurück, die sich mit diesem hier überlappen.
        """
        return BPZeitraum.objects.filter(
            Q(anfang__gte=self.anfang, anfang__lte=self.ende)
            | Q(anfang__lte=self.anfang, ende__gte=self.anfang)
        )

    def anzahl_ueberlappende_bp_zeitraeume(self):
        return self.ueberlappende_bp_zeitraeume().count()

    def ueberlappende_pj_zeitraeume(self):
        """
        Gibt alle PJ-Zeiträume zurück, die sich mit diesem hier überlappen.
        """
        return PJZeitraum.objects.filter(
            Q(anfang__gte=self.anfang, anfang__lte=self.ende)
            | Q(anfang__lte=self.anfang, ende__gte=self.anfang)
        )


class BPZeitraum(Zeitraum):
    """
    Ein BP-Zeitraum ist einem BP-Block zugeordnet.
    Er hat ein Anfang und ein Ende.
    """

    class Meta:
        verbose_name = 'BP-Zeitraum'
        verbose_name_plural = 'BP-Zeiträume'
        ordering = ['anfang']

    bp_block = models.ForeignKey(
        BPBlock,
        related_name='bp_zeitraeume',
        verbose_name='BP-Block'
    )
    # TODO: vielleicht mal in ueberlappende_bp umbenennen.
    # Dann wäre das alles konsistenter.
    ueberlappende = models.ManyToManyField(
        'self',
        related_name='+',
        db_table='ueberlappende_bp_zeitraeume',
        symmetrical=True,
        blank=True,
        verbose_name='Überlappende BP-Zeiträume',
    )
    # ueberlappende_pj ist auch vorhanden und wird in PJZeitraum als
    # related_field über ueberlappende_bp definiert.

    def get_absolute_url(self):
        return reverse('bp_cupid:bpzeitraum_detail', args=[str(self.id)])

    def __str__(self):
        return 'BP: ' + super().__str__()

    def aktualisiere_bp_zeitraeume(self):
        """
        Löscht alle überlappenden BP-Zeiträume und berechnet sie dann neu.
        """
        for zr in self.ueberlappende.all():
            self.ueberlappende.remove(zr)

        for zr in self.ueberlappende_bp_zeitraeume():
            self.ueberlappende.add(zr)

    def aktualisiere_pj_zeitraeume(self):
        """
        Löscht alle überlappenden PJ-Zeiträume und berechnet sie dann neu.
        """
        for zr in self.ueberlappende_pj.all():
            self.ueberlappende_pj.remove(zr)

        for zr in self.ueberlappende_pj_zeitraeume():
            self.ueberlappende_pj.add(zr)

    def aktualisiere_zeitraeume(self):
        """
        Aktualisiert BP- und PJ-Zeiträume in einem Rutsch.
        """
        self.aktualisiere_bp_zeitraeume()
        self.aktualisiere_pj_zeitraeume()


class PJZeitraum(Zeitraum):
    class Meta:
        verbose_name = 'PJ-Zeitraum'
        verbose_name_plural = 'PJ-Zeiträume'
        ordering = ['anfang']

    pj_block = models.ForeignKey(
        PJBlock,
        related_name='pj_zeitraeume',
        verbose_name='PJ-Block'
    )

    def get_absolute_url(self):
        return reverse('bp_cupid:pjzeitraum_detail', args=[str(self.id)])

    def __str__(self):
        return 'PJ: ' + super().__str__()

    # TODO: vielleicht mal in ueberlappende_pj umbenennen.
    # Dann wäre das alles konsistenter.
    ueberlappende = models.ManyToManyField(
        'self',
        related_name='+',
        db_table='ueberlappende_pj_zeitraeume',
        symmetrical=True,
        blank=True,
        verbose_name='Überlappende PJ-Zeiträume',
    )

    ueberlappende_bp = models.ManyToManyField(
        BPZeitraum,
        related_name='ueberlappende_pj',
        blank=True,
        db_table='ueberlappende_bp_pj',
        verbose_name='Überlappende BP-Zeiträume',
    )

    def aktualisiere_bp_zeitraeume(self):
        """
        Löscht alle überlappenden BP-Zeiträume und berechnet sie dann neu.
        """
        for zr in self.ueberlappende_bp.all():
            self.ueberlappende_bp.remove(zr)

        for zr in self.ueberlappende_bp_zeitraeume():
            self.ueberlappende_bp.add(zr)

    def aktualisiere_pj_zeitraeume(self):
        """
        Löscht alle überlappenden PJ-Zeiträume und berechnet sie dann neu.
        """
        for zr in self.ueberlappende.all():
            self.ueberlappende.remove(zr)

        for zr in self.ueberlappende_pj_zeitraeume():
            self.ueberlappende.add(zr)

    def aktualisiere_zeitraeume(self):
        """
        Aktualisiert BP- und PJ-Zeiträume in einem Rutsch.
        """
        self.aktualisiere_bp_zeitraeume()
        self.aktualisiere_pj_zeitraeume()
