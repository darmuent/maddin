"""
Ein Abrechnungszeitraum liegt zwischen einem BP-Verwaltungszeitraum und einer
Abrechnungsdetail. Ein Abrechnungsdetail speichert die Daten zu einer Praxis
und einem Abrechnungszeitraum.

┌───────────────────────┐
│ BPVerwaltungszeitraum │
└───────────────────────┘
            ↑
            │
 ┌─────────────────────┐
 │ Abrechnungszeitraum │
 └─────────────────────┘
            ↑
            │
  ┌───────────────────┐    ┌────────┐
  │ Abrechnungsdetail │───→│ Praxis │
  └───────────────────┘    └────────┘

Speichert ein paar Daten (Datumswerte), die man sich nicht merken möchte.
"""

from django.db import models
from django.core.urlresolvers import reverse

from simple_history.models import HistoricalRecords

from . import (
    Praxis,
    BPVerwaltungszeitraum,
)


class Abrechnungszeitraum(models.Model):
    class Meta:
        verbose_name = 'Abrechnungszeitraum'
        verbose_name_plural = 'Abrechnungszeiträume'
        unique_together = ('bp_verwaltungszeitraum', 'name')

    bp_verwaltungszeitraum = models.ForeignKey(
        BPVerwaltungszeitraum,
        related_name='abrechnungszeitraum',
        verbose_name='BP-Verwaltungszeitraum',
    )

    name = models.CharField(
        max_length=100,
        verbose_name='Name',
        default='Abrechnungszeitraum 0',
    )

    def get_absolute_url(self):
        return reverse(
            'bp_cupid:abrechnungszeitraum_detail',
            args=[str(self.id)]
        )

    def __str__(self):
        return '{name} ({verwzr})'.format(
            name=self.name,
            verwzr=self.bp_verwaltungszeitraum,
        )

    def __repr__(self):
        return '<Abrechnungszeitraum: {name} ({verwzr})>'.format(
            name=self.name,
            verwzr=self.bp_verwaltungszeitraum,
        )


class Abrechnungsdetail(models.Model):
    class Meta:
        verbose_name = 'Abrechnungsdetail'
        verbose_name_plural = 'Abrechnungsdetails'
        unique_together = ('abrechnungszeitraum', 'praxis')

    def __str__(self):
        return 'Abrechnungsdetail für Praxis {praxis} in {verwzr}'.format(
            praxis=self.praxis,
            verwzr=self.bp_verwaltungszeitraum,
        )

    praxis = models.ForeignKey(
        Praxis,
        related_name='abrechnungsdetail',
    )
    abrechnungszeitraum = models.ForeignKey(
        Abrechnungszeitraum,
        related_name='abrechnungsdetail',
    )

    erstellt = models.DateField(
        blank=True,
        null=True,
        verbose_name='Rechnung erstellt am',
    )
    eingegangen = models.DateField(
        blank=True,
        null=True,
        verbose_name='Rechnung eingegangen am',
    )
    weiterleitung_an_df = models.DateField(
        blank=True,
        null=True,
        verbose_name='Rechnung weitergeleitet an DF am',
    )
    buchung_erfolgt = models.DateField(
        blank=True,
        null=True,
        verbose_name='Buchung ist erfolgt am',
    )
    erinnerung_an_la = models.DateField(
        blank=True,
        null=True,
        verbose_name='LA wurde nochmal erinnert am',
    )

    history = HistoricalRecords()
