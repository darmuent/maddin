"""
Eine Praxis.
"""

from django.db import models
try:
    from django.apps import apps
    get_model = apps.get_model
except ImportError:
    from django.db.models.loading import get_model
from django.utils.http import urlquote
from django.core.urlresolvers import reverse

from io import BytesIO
from operator import attrgetter
from textwrap import dedent

from geoposition.fields import GeopositionField

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate
from reportlab.platypus.tables import Table

from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Cm, Mm, Pt, RGBColor

from . import (
    Landkreis,
    BPZeitraum,
    PJZeitraum,
)


class PraxisManager(models.Manager):
    """
    Besondere Funktionen für alle Praxen.
    """
    def frei(self):
        return [p for p in self.all() if p.freie_bp_zeitraeume.exists()]


class Praxis(models.Model):
    """
    Eine Praxis liegt in einem Landkreis und bietet BP-Zeiträume an, in denen
    Blockpraktikanten angenommen werden. Weiterhin besitzt sie einige
    persönliche und BP-relevante Daten.
    """
    # Relationen
    landkreis = models.ForeignKey(
        Landkreis,
        null=True,
        related_name='praxen',
    )
    bp_zeitraeume = models.ManyToManyField(
        BPZeitraum,
        db_table='praxis_bp_zeitraum',
        verbose_name='BP-Zeiträume',
        blank=True,
        related_name='bp_praxen',
    )
    freie_bp_zeitraeume = models.ManyToManyField(
        BPZeitraum,
        db_table='praxis_bp_zeitraum_frei',
        verbose_name='freie BP-Zeiträume',
        blank=True,
        related_name='bp_praxen_frei',
    )
    belegte_bp_zeitraeume = models.ManyToManyField(
        BPZeitraum,
        db_table='praxis_bp_zeitraum_belegt',
        verbose_name='belegte BP-Zeiträume',
        blank=True,
        related_name='bp_praxen_belegt',
    )

    pj_zeitraeume = models.ManyToManyField(
        PJZeitraum,
        db_table='praxis_pj_zeitraum',
        verbose_name='PJ-Zeiträume',
        blank=True,
        related_name='pj_praxen',
    )
    freie_pj_zeitraeume = models.ManyToManyField(
        PJZeitraum,
        db_table='praxis_pj_zeitraum_frei',
        verbose_name='freie PJ-Zeiträume',
        blank=True,
        related_name='pj_praxen_frei',
    )
    belegte_pj_zeitraeume = models.ManyToManyField(
        PJZeitraum,
        db_table='praxis_pj_zeitraum_belegt',
        verbose_name='belegte PJ-Zeiträume',
        blank=True,
        related_name='pj_praxen_belegt',
    )

    objects = PraxisManager()

    # persönliche Daten
    anrede = models.CharField(max_length=15, blank=True, default='')
    vorname = models.CharField(max_length=100)
    name = models.CharField(max_length=100)
    sortierschluessel = models.CharField(
        max_length=100,
        blank=True,
        null=True,  # wichtig für Coalesce
        verbose_name='Sortierschlüssel',
        help_text=(
            'Wenn gesetzt, dann wird die Praxis danach einsortiert, '
            'ansonsten nach dem Namen.'
        ),
    )
    adresse = models.CharField(max_length=100, blank=True)
    position = GeopositionField(blank=True)
    ist_vip = models.BooleanField(
        default=False,
        verbose_name='ist VIP',
        help_text='Wird auf der Karte besonders angezeigt.',
    )
    plz = models.IntegerField(default=0)
    ort = models.CharField(max_length=50, blank=True, default='')
    telefon = models.CharField(max_length=20, blank=True, default='')
    telefax = models.CharField(max_length=20, blank=True, default='')
    homepage = models.URLField(blank=True, default='')
    email = models.EmailField(blank=True, default='')
    ist_aktiv = models.BooleanField(default=True, verbose_name='ist aktiv')
    hat_didaktikschulung_besucht = models.BooleanField(
        default=False,
        verbose_name='hat Didaktikschulung besucht'
    )
    hat_bp_urkunde_erhalten = models.BooleanField(
        default=False,
        verbose_name='hat BP-Urkunde erhalten',
    )
    hat_pj_urkunde_erhalten = models.BooleanField(
        default=False,
        verbose_name='hat PJ-Urkunde erhalten',
    )
    beginn_bp_lehrtaetigkeit = models.DateField(
        blank=True,
        null=True,
        verbose_name='Beginn der BP-Lehrtätigkeit',
        help_text='Wird als Datum gespeichert. Zum Beispiel 30.09.2016',
    )
    beginn_pj_lehrtaetigkeit = models.DateField(
        blank=True,
        null=True,
        verbose_name='Beginn der PJ-Lehrtätigkeit',
        help_text='Wird als Datum gespeichert. Zum Beispiel 30.09.2016',
    )

    # BP-relevante Daten
    unterkunft = models.CharField(
        max_length=100,
        blank=True,
        default=''
    )
    lehre_bp = models.BooleanField(
        default=False,
        verbose_name='BP'
    )
    lehre_pj = models.BooleanField(
        default=False,
        verbose_name='PJ'
    )
    kinder = models.BooleanField(
        default=False,
        verbose_name='Kinder/Jugendliche'
    )
    sono = models.BooleanField(
        default=False,
        verbose_name='Sonografie'
    )
    sport = models.BooleanField(
        default=False,
        verbose_name='Sportmedizin'
    )
    kompl = models.BooleanField(
        default=False,
        verbose_name='Komplementärmedizin'
    )
    bundeswehr = models.BooleanField(
        default=False,
        verbose_name='Gehört zur Bundeswehr'
    )
    ist_landarztpraxis = models.BooleanField(
        default=False,
        verbose_name='ist Landarztpraxis',
    )
    freie_unterkunft = models.BooleanField(
        default=False,
        verbose_name='freie UK?',
        help_text='freie Unterkunft',
    )
    billige_unterkunft = models.BooleanField(
        default=False,
        verbose_name='billige UK?',
        help_text='billige Unterkunft',
    )
    nur_mit_auto = models.BooleanField(
        default=False,
        verbose_name='nur Auto',
        help_text='nur mit Auto erreichbar?',
    )
    erg_taetigkeiten = models.TextField(
        blank=True,
        verbose_name='Ergänzungen zu den abgefragten Tätigkeitsschwerpunkten'
    )
    andere_kriterien = models.TextField(
        blank=True,
        verbose_name='andere Kriterien'
    )
    erg_unterbringung = models.TextField(
        blank=True,
        verbose_name='Ergänzungen zu den Angaben zur Unterbringung')
    sonstiges = models.TextField(
        blank=True,
        verbose_name='Sonstiges'
    )
    interne_notizen = models.TextField(
        blank=True,
        default='',
        verbose_name='interne Notizen'
    )

    def sortierte_bp_zeitraeume(self):
        """
        Gibt die angebotenen BP-Zeiträume sortiert zurück.
        """
        return self.bp_zeitraeume.order_by('anfang')

    def anzahl_bp_zeitraeume(self):
        """
        Gibt die Anzahl der BP-Zeiträume zurück.
        """
        return self.bp_zeitraeume.count()

    def erster_freier_bp_zeitraum(self):
        """
        Gibt den ersten freien BP-Zeitraum der Praxis zurück. Falls alle
        BP-Zeiträume belegt sind, wird None zurückgegeben.
        """
        return self.freie_bp_zeitraeume.first()

    def aktualisiere_zeitraeume(self, bp_verw_zr=None, pj_verw_zr=None):
        """
        Organisiert die freien und belegten BP-Zeiträume.

        Alle direkt und indirekt belegten BP-Zeiträume kommen in
        belegte_bp_zeitraeume; alle angebotenen BP-Zeiträume, die nicht belegt
        sind, kommen in freie_bp_zeitraeume.

        Dabei kann ein BP-Zeitraum "belegt" sein, selbst wenn dieser von der
        Praxis gar nicht angeboten wird (weil er indirekt belegt wird).
        """

        # Erstmal alle relevanten Zeiträume einsammeln:
        if bp_verw_zr:
            eigene_bp_zeitraeume = self.bp_zeitraeume.filter(
                bp_block__bp_verwaltungszeitraum=bp_verw_zr
            )
            freie_bp_zeitraeume = self.freie_bp_zeitraeume.filter(
                bp_block__bp_verwaltungszeitraum=bp_verw_zr
            )
            belegte_bp_zeitraeume = self.belegte_bp_zeitraeume.filter(
                bp_block__bp_verwaltungszeitraum=bp_verw_zr
            )
            bp_plaetze = self.bpplatz_related.filter(
                bp_zeitraum__bp_block__bp_verwaltungszeitraum=bp_verw_zr
            )
        else:
            eigene_bp_zeitraeume = self.bp_zeitraeume.all()
            freie_bp_zeitraeume = self.freie_bp_zeitraeume.all()
            belegte_bp_zeitraeume = self.belegte_bp_zeitraeume.all()
            bp_plaetze = self.bpplatz_related.all()

        if pj_verw_zr:
            eigene_pj_zeitraeume = self.pj_zeitraeume.filter(
                pj_block__pj_verwaltungszeitraum=pj_verw_zr
            )
            freie_pj_zeitraeume = self.freie_pj_zeitraeume.filter(
                pj_block__pj_verwaltungszeitraum=pj_verw_zr
            )
            belegte_pj_zeitraeume = self.belegte_pj_zeitraeume.filter(
                pj_block__pj_verwaltungszeitraum=pj_verw_zr
            )
            pj_plaetze = self.pjplatz_related.filter(
                pj_zeitraum__pj_block__pj_verwaltungszeitraum=pj_verw_zr
            )
        else:
            eigene_pj_zeitraeume = self.pj_zeitraeume.all()
            freie_pj_zeitraeume = self.freie_pj_zeitraeume.all()
            belegte_pj_zeitraeume = self.belegte_pj_zeitraeume.all()
            pj_plaetze = self.pjplatz_related.all()

        # dann aufräumen:
        self.freie_bp_zeitraeume.remove(*freie_bp_zeitraeume)
        self.belegte_bp_zeitraeume.remove(*belegte_bp_zeitraeume)
        self.freie_pj_zeitraeume.remove(*freie_pj_zeitraeume)
        self.belegte_pj_zeitraeume.remove(*belegte_pj_zeitraeume)

        # erst die belegten:
        for bp_platz in bp_plaetze:
            # Welche BP-Zeiträume werden von den BP-Plätzen belegt?
            ueberl_bp_zeitraeume = bp_platz.bp_zeitraum.ueberlappende_bp_zeitraeume()
            self.belegte_bp_zeitraeume.add(*ueberl_bp_zeitraeume)
            # Welche PJ-Zeiträume werden von den BP-Plätzen belegt?
            ueberl_pj_zeitraeume = bp_platz.bp_zeitraum.ueberlappende_pj_zeitraeume()
            self.belegte_pj_zeitraeume.add(*ueberl_pj_zeitraeume)

        for pj_platz in pj_plaetze:
            # Welche PJ-Zeiträume werden von den PJ-Plätzen belegt?
            ueberl_pj_zeitraeume = pj_platz.pj_zeitraum.ueberlappende_pj_zeitraeume()
            self.belegte_pj_zeitraeume.add(*ueberl_pj_zeitraeume)

            # Welche BP-Zeiträume werden von den PJ-Plätzen belegt?
            ueberl_bp_zeitraeume = pj_platz.pj_zeitraum.ueberlappende_bp_zeitraeume()
            self.belegte_bp_zeitraeume.add(*ueberl_bp_zeitraeume)

        # dann die freien:
        for pj_zeitraum in eigene_pj_zeitraeume:
            if pj_zeitraum not in self.belegte_pj_zeitraeume.all():
                self.freie_pj_zeitraeume.add(pj_zeitraum)

        for bp_zeitraum in eigene_bp_zeitraeume:
            if bp_zeitraum not in self.belegte_bp_zeitraeume.all():
                self.freie_bp_zeitraeume.add(bp_zeitraum)

    def freie_bp_zeitraeume_in_bp_block(self, bp_block):
        """
        Gibt die freien BP-Zeiträume der Praxis vom übergebenen BP-Block
        zurück.
        """
        bp_block_bp_zeitraeume = bp_block.bp_zeitraeume.all()
        return sorted(
            set(self.freie_bp_zeitraeume.all()) & set(bp_block_bp_zeitraeume),
            key=attrgetter('anfang'),
        )

    def bpplatzbegrenzung_erfuellt(self, bp_verw_zr):
        """
        Ermittelt, ob die BP-Platzbegrenzung noch nicht erreicht wurde (also
        Anzahl der BP-Plätze < BP-Platzbegrenzung).
        """
        BPPlatzbegrenzung = get_model('bp_cupid', 'BPPlatzbegrenzung')

        try:
            pgrenze = self.bpplatzbegrenzung.get(
                bp_verwaltungszeitraum=bp_verw_zr
            )
            anzahl_bp_plaetze = self.bpplatz_related.filter(
                bp_zeitraum__bp_block__bp_verwaltungszeitraum=bp_verw_zr,
            ).count()
            return anzahl_bp_plaetze < pgrenze.anzahl
        except BPPlatzbegrenzung.DoesNotExist:
            return True

    def hat_freien_bp_zeitraum_in_bp_block(self, bp_block):
        """
        Gibt an, ob die Praxis in diesem BP-Block noch freie BP-Zeiträume hat.
        """
        return (
            bool(self.freie_bp_zeitraeume_in_bp_block(bp_block)) and
            self.bpplatzbegrenzung_erfuellt(bp_block.bp_verwaltungszeitraum)
        )

    def voll_belegt(self, bp_verwaltungszeitraum):
        """
        Gibt an, ob die Praxis im übergebenen BP-Verwaltungszeitraum schon voll
        belegt ist.
        """
        return not (
                self.bpplatzbegrenzung_erfuellt(bp_verwaltungszeitraum)
                and
                self.freie_bp_zeitraeume.filter(
                    bp_block__bp_verwaltungszeitraum=bp_verwaltungszeitraum
                ).exists()
        )

    def kapazitaet(self, bp_block):
        """
        Gibt die Kapazität der Praxis vom übergebenen BP-Block zurück.
        """
        k = 0
        ueberl = set()

        for zeitr in bp_block.bp_zeitraeume.all():
            if zeitr in self.bp_zeitraeume.all() and zeitr not in ueberl:
                k += 1
                ueberl.update(zeitr.ueberlappende.all())

        return k

    def maps_link(self):
        """
        Gibt einen Link zu Google Maps zurück.
        """
        maps_url = 'https://www.google.de/maps/place/'
        return maps_url + urlquote(
                self.adresse + ' '
                + str(self.plz) + ' '
                + self.ort
        )

    def pdf_elemente(self, bp_verwaltungszeitraum):
        """
        Erzeugt eine Liste von Elementen für die Erstellung der PDF-Übersicht
        mit ReportLab.
        """

        # anfangs richten wir unsere Stylesheets ein:
        styles = getSampleStyleSheet()
        styleH1 = styles['Heading1']
        styleH2 = styles['Heading2']
        styleN = styles['BodyText']
        styleN.spaceAfter = 6

        """
        Für die PDF-Übersicht brauchen wir eine Liste von Elementen aus dem
        Fundus von ReportLab. Wir legen die Liste an und befüllen sie mit den
        ersten Überschriften und Absätzen.
        """
        elements = []
        elements.append(Paragraph('Einteilung des Blockpraktikums', styleH1))
        par_einteilung = """
        Für die Praxis von {praxis.anrede} {praxis.name} wurden im
        BP-Verwaltungszeitraum {bp_verw_zr.name} folgende Studenten eingeteilt:
        """
        par_einteilung = par_einteilung.format(
            praxis=self,
            bp_verw_zr=bp_verwaltungszeitraum
        )
        par_einteilung = par_einteilung.replace('Herr', 'Herrn')
        elements.append(Paragraph(par_einteilung, styleN))

        # die Platztabelle ist intern nur eine Liste von Tupeln:
        plaetze = [
            # Überschriften:
            (
                Paragraph('<b>Beginn</b>', styleN),
                Paragraph('<b>Ende</b>', styleN),
                Paragraph('<b>Name</b>', styleN)
            )
        ] + [
            # die eigentlichen Plätze:
            (
                p.bp_zeitraum.anfang.strftime("%d.%m.%Y"),
                p.bp_zeitraum.ende.strftime("%d.%m.%Y"),
                p.student.vorname + " " + p.student.name,
            )
            for p in self.bpplatz_related.filter(
                bp_zeitraum__bp_block__bp_verwaltungszeitraum=bp_verwaltungszeitraum
            ).order_by('bp_zeitraum')
        ]
        # TODO: die PJ-Plätze hinzufügen
        tab_plaetze = Table(plaetze, style=[
            ('LINEABOVE', (0, 1), (-1, 1), 1, (0, 0, 0))]
        )
        elements.append(tab_plaetze)

        """
        Die Zusatzinformationen werden nur hinzugefügt, wenn sie auch
        existieren und der Text nicht leer ist.
        """
        ZusatzinfoPraxis = get_model('bp_cupid', 'ZusatzinfoPraxis')
        try:
            zusatzinfo = self.zusatzinfopraxis_set.get(
                bp_verwaltungszeitraum=bp_verwaltungszeitraum
            )
            if zusatzinfo.text:
                elements.append(Paragraph('Zusatzinformationen', styleH2))
                for par in zusatzinfo.text.splitlines():
                    if par:
                        elements.append(Paragraph(par, styleN))
        except ZusatzinfoPraxis.DoesNotExist:
            pass

        return elements

    def pdf(self, bp_verwaltungszeitraum):
        """
        Erzeugt die PDF-Übersicht der Praxis. Gibt die reinen Bytes zurück.
        """
        elements = self.pdf_elemente(
            bp_verwaltungszeitraum=bp_verwaltungszeitraum
        )
        with BytesIO() as buf:
            doc = SimpleDocTemplate(buf, pagesize=A4)
            doc.build(elements)
            pdf_content = buf.getvalue()
        return pdf_content

    def komplette_adresse(self):
        kompl_adr = '{anrede} {vorname} {name}\n{adresse}\n{plz} {ort}'.format(
            anrede=self.anrede,
            vorname=self.vorname,
            name=self.name,
            adresse=self.adresse,
            plz=self.plz,
            ort=self.ort,
        )
        return kompl_adr

    def voller_name(self):
        """
        Für Überschriften auf der Webseite.
        """
        return '{anrede} {vorname} {name}'.format(
            anrede=self.anrede,
            vorname=self.vorname,
            name=self.name,
        )

    @property
    def kurzer_name(self):
        """
        Kürzt den Namen auf 'A. Turing' ab. Wenn die Praxis aber von mehreren
        Ärzten besetzt wird, dann brauchen wir etwas mehr Hirnschmalz.

        Wir gehen bei mehreren Ärzten davon aus, dass die Namen im Vornamen
        abgespeichert sind und der Nachname nur einen weiteren Namen enthält.
        """
        r = ''
        if ',' in self.vorname:
            namen_in_vorname = [
                name.strip()
                for name in self.vorname.split(',')
                if name.strip()
            ]
            for name in namen_in_vorname:
                p = name.split()
                r += '{}. {}, '.format(
                    p[0][0],  # Anfangsbuchstabe vom Vornamen
                    ' '.join(p[1:])
                )
            name_in_nachname = self.name.split()
            r += '{}. {}'.format(
                name_in_nachname[0][0],
                ' '.join(name_in_nachname[1:])
            )
            return r
        else:
            return '{}. {}'.format(self.vorname[0], self.name)

    def volle_adresse(self):
        """
        Für Überschriften auf der Webseite.
        """
        return '{adresse}, {plz} {ort}'.format(
            adresse=self.adresse,
            plz=self.plz,
            ort=self.ort,
        )

    @property
    def sortierung(self):
        """
        Wenn man die Praxen nach sortierschluessel und name sortieren mittels
        .order_by() sortieren will, dann muss man Coalesce nutzen.

        Das hier ist für die Sortierung mit der sorted()-Funktion.
        """
        return self.sortierschluessel or self.name

    def add_abrechnungselemente(
            self,
            doc=None,
            bp_verwaltungszeitraum=None,
            anzahl_bp_plaetze=0
            ):
        """
        Fügt einem Docx-Dokument die Abrechnungselemente der Praxis hinzu. Das
        Dokument wird im View erzeugt. Die Anzahl der BP-Plätze werden auch im
        View bestimmt.
        """
        betrag = '{},00'.format(anzahl_bp_plaetze * 250)

        absender_text = 'Absender: Lehrarztpraxis\n{}'.format(
            self.komplette_adresse()
        )
        absender = doc.add_paragraph(dedent(absender_text).strip())

        absender.style.font.name = 'Arial'
        absender.style.font.size = Pt(10)

        absender.paragraph_format.space_after = Cm(1)

        rechnung_und_datum = doc.add_table(rows=1, cols=2)

        rechnung_und_datum.cell(0, 0).text = 'RECHNUNG'
        rechnung_und_datum.cell(0, 0).paragraphs[0].runs[0].bold = True
        rechnung_und_datum.cell(0, 0).paragraphs[0].paragraph_format.space_after = Cm(1) # noqa
        rechnung_und_datum.cell(0, 0).width = Cm(12)
        rechnung_und_datum.cell(0, 1).width = Cm(5)

        rechnung_und_datum.cell(0, 1).text = 'Datum:'

        empfaenger_text = """
            Institut für Allgemeinmedizin
            Universitätsmedizin Rostock
            Beate Schlegel
            Postfach 10 08 88
            18055 Rostock
        """
        empfaenger = doc.add_paragraph(dedent(empfaenger_text).strip())

        empfaenger.paragraph_format.space_after = Cm(1)

        rechnungsnr_und_steuernr = doc.add_table(rows=1, cols=2)

        rechnungsnr_zelle = rechnungsnr_und_steuernr.cell(0, 0)
        rechnungsnr_zelle.text = 'Rechnungs-Nr.:'
        rechnungsnr_zelle.paragraphs[0].runs[0].bold = True
        rechnungsnr_zelle.paragraphs[0].paragraph_format.space_after = Cm(1)
        rechnungsnr_zelle.width = Cm(12)

        steuernr_zelle = rechnungsnr_und_steuernr.cell(0, 1)
        steuernr_zelle.text = 'Steuer-Nummer:'
        steuernr_zelle.paragraphs[0].runs[0].bold = True
        steuernr_zelle.paragraphs[0].paragraph_format.space_after = Cm(1)
        steuernr_zelle.width = Cm(5)

        rechnungsnr_und_steuernr.style = doc.styles['Table Grid']

        platzhalter = doc.add_paragraph()
        platzhalter.paragraph_format.space_before = Cm(0)
        platzhalter.paragraph_format.space_after = Cm(0)

        leistungen = doc.add_table(rows=2, cols=3)

        leistungen.cell(0, 0).text = 'Leistungen und Leistungszeitraum'
        leistungen.cell(0, 0).paragraphs[0].runs[0].bold = True
        leistungen.cell(0, 0).width = Cm(7.5)

        leistungen.cell(0, 1).text = 'Anzahl Studierende × Tage'
        leistungen.cell(0, 1).paragraphs[0].runs[0].bold = True
        leistungen.cell(0, 1).width = Cm(5)

        leistungen.cell(0, 2).text = 'Summe'
        leistungen.cell(0, 2).paragraphs[0].runs[0].bold = True
        leistungen.cell(0, 2).width = Cm(4.5)
        leistungen.cell(0, 2).paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT # noqa

        leistungen.cell(1, 0).text = (
                'Honorar für die Studierendenausbildung im Blockpraktikum '
                'Allgemeinmedizin im\n'
        )
        leistungen.cell(1, 0).width = Cm(7.5)
        semester = leistungen.cell(1, 0).paragraphs[0].add_run(bp_verwaltungszeitraum) # noqa
        semester.font.bold = True
        umr_rot = RGBColor(0xCE, 0, 0x60)
        semester.font.color.rgb = umr_rot

        leistungen.cell(1, 1).text = '{} × 8'.format(anzahl_bp_plaetze)
        leistungen.cell(1, 1).paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER # noqa
        leistungen.cell(1, 1).paragraphs[0].paragraph_format.space_before = Mm(4) # noqa
        leistungen.cell(1, 1).width = Cm(5)

        leistungen.cell(1, 2).text = '{} €'.format(betrag)
        leistungen.cell(1, 2).paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT # noqa
        leistungen.cell(1, 2).paragraphs[0].paragraph_format.space_before = Mm(4) # noqa
        leistungen.cell(1, 2).width = Cm(4.5)

        leistungen.style = doc.styles['Table Grid']

        platzhalter = doc.add_paragraph()
        platzhalter.paragraph_format.space_before = Cm(0)
        platzhalter.paragraph_format.space_after = Mm(3)

        endsumme = doc.add_table(rows=1, cols=2)

        endsumme.cell(0, 0).text = 'Endsumme in EURO:'
        endsumme.cell(0, 0).paragraphs[0].runs[0].bold = True
        endsumme.cell(0, 0).paragraphs[0].runs[0].font.color.rgb = umr_rot

        endsumme.cell(0, 1).text = '{} Euro'.format(betrag)
        endsumme.cell(0, 1).paragraphs[0].runs[0].bold = True
        endsumme.cell(0, 1).paragraphs[0].runs[0].font.color.rgb = umr_rot
        endsumme.cell(0, 1).paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

        hinweis_ueberweisung = doc.add_paragraph(
            'Ich bitte um Überweisung der Endsumme auf folgendes Konto:'
        )
        hinweis_ueberweisung.paragraph_format.space_before = Cm(1)
        hinweis_ueberweisung.paragraph_format.space_after = Cm(0)

        kontodaten = doc.add_table(rows=3, cols=2)

        kontodaten.cell(0, 0).text = 'IBAN:'
        kontodaten.cell(0, 0).paragraphs[0].runs[0].bold = True
        kontodaten.cell(0, 0).paragraphs[0].paragraph_format.space_before = Mm(3) # noqa
        kontodaten.cell(0, 0).width = Cm(3)

        kontodaten.cell(0, 1).text = ''
        kontodaten.cell(0, 1).paragraphs[0].paragraph_format.space_after = Cm(1) # noqa
        kontodaten.cell(0, 1).width = Cm(14)

        kontodaten.cell(1, 0).text = 'BIC:'
        kontodaten.cell(1, 0).paragraphs[0].runs[0].bold = True
        kontodaten.cell(1, 0).paragraphs[0].paragraph_format.space_before = Mm(3) # noqa
        kontodaten.cell(1, 0).width = Cm(3)

        kontodaten.cell(1, 1).text = ''
        kontodaten.cell(1, 1).paragraphs[0].paragraph_format.space_after = Cm(1) # noqa
        kontodaten.cell(1, 1).width = Cm(14)

        kontodaten.cell(2, 0).text = 'Kreditinstitut:'
        kontodaten.cell(2, 0).paragraphs[0].runs[0].bold = True
        kontodaten.cell(2, 0).paragraphs[0].paragraph_format.space_before = Mm(3) # noqa
        kontodaten.cell(2, 0).width = Cm(3)

        kontodaten.cell(2, 1).text = ''
        kontodaten.cell(2, 1).paragraphs[0].paragraph_format.space_after = Cm(1) # noqa
        kontodaten.cell(2, 1).width = Cm(14)

        kontodaten.style = doc.styles['Table Grid']

        platzhalter = doc.add_paragraph()
        platzhalter.paragraph_format.space_before = Cm(0)
        platzhalter.paragraph_format.space_after = Cm(0)

        kontoinhaber = doc.add_table(rows=1, cols=1)

        kontoinhaber_text = kontoinhaber.cell(0, 0).paragraphs[0].add_run('Kontoinhaber') # noqa
        kontoinhaber_text.bold = True

        kontoinhaber.cell(0, 0).paragraphs[0].add_run(
            ' (falls abweichend von der/dem Rechnungssteller/in)'
        ).font.size = Pt(8)

        kontoinhaber.cell(
            0, 0
        ).paragraphs[0].paragraph_format.space_after = Cm(1)

        kontoinhaber.style = doc.styles['Table Grid']

        praxisunterschrift_und_kostenstelle = doc.add_table(rows=1, cols=2)

        praxisunterschrift_zelle = praxisunterschrift_und_kostenstelle.cell(0, 0) # noqa
        praxisunterschrift_zelle.width = Cm(9)
        praxisunterschrift_zelle.text = 57*'.' + '\n'
        praxisunterschrift_zelle.paragraphs[0].paragraph_format.space_before = Cm(3) # noqa
        praxisunterschrift = praxisunterschrift_zelle.paragraphs[0].add_run(
            '(Unterschrift und Praxisstempel)'
        )
        praxisunterschrift.font.size = Pt(9)

        kostenstelle_zelle = praxisunterschrift_und_kostenstelle.cell(0, 1)
        kostenstelle_zelle.width = Cm(8)

        kostenstelle = kostenstelle_zelle.add_table(rows=3, cols=1)
        kostenstelle.style = doc.styles['Table Grid']

        kostenstelle.cell(0, 0).paragraphs[0].add_run('Kostenstelle').bold = True # noqa
        kostenstelle.cell(0, 0).paragraphs[0].add_run(
            ' (Institut für Allgemeinmedizin):'
        )
        kostenstelle.cell(0, 0).paragraphs[0].paragraph_format.space_before = Mm(2) # noqa

        kostenstelle_zahl_p = kostenstelle.cell(0, 0).add_paragraph()
        kostenstelle_zahl_r = kostenstelle_zahl_p.add_run('883310')
        kostenstelle_zahl_r.bold = True
        kostenstelle_zahl_p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        kostenstelle_zahl_p.paragraph_format.space_before = Mm(1)
        kostenstelle_zahl_p.paragraph_format.space_after = Mm(1)

        richtigkeit = kostenstelle.cell(1, 0).paragraphs[0].add_run(
            'sachl./rechn.\n'
            'richtig:\n'
        )
        richtigkeit.bold = True
        richtigkeit.font.size = Pt(9)
        kostenstelle.cell(1, 0).paragraphs[0].add_run(
            '(Prof. Dr. med. A. Altiner / B. Schlegel / S. Hoffmann)'
        ).font.size = Pt(8)
        kostenstelle.cell(1, 0).paragraphs[0].paragraph_format.space_before = Mm(1) # noqa
        kostenstelle.cell(1, 0).paragraphs[0].paragraph_format.space_after = Mm(1) # noqa

        kostenstelle.cell(2, 0).text = ''
        kostenstelle.cell(2, 0).paragraphs[0].paragraph_format.space_after = Cm(1) # noqa

        return doc

    class Meta:
        verbose_name = 'Praxis'
        verbose_name_plural = 'Praxen'

    def get_absolute_url(self):
        return reverse('bp_cupid:praxis', args=[str(self.id)])

    def __str__(self):
        return '%s %s (%s)' % (self.vorname, self.name, self.id)
