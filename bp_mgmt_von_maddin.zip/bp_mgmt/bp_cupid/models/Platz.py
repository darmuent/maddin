from django.db import models
from django.core.exceptions import ValidationError
from django.core.urlresolvers import reverse
from django.utils.safestring import mark_safe

from simple_history.models import HistoricalRecords

from . import (
    BPZeitraum,
    Gewicht,
    PJZeitraum,
    Praxis,
    Student,
)

import logging
logger = logging.getLogger(__name__)


class Platz(models.Model):
    """
    Ein abstrakter Platz.
    """
    class Meta:
        abstract = True

    # Relationen
    praxis = models.ForeignKey(
        Praxis,
        related_name='%(class)s_related'
    )
    kommentar = models.TextField(
        default='',
        blank=True,
    )


class BPPlatz(Platz):
    """
    Einem BP-Platz sind ein Student, eine Praxis und ein BP-Zeitraum
    zugeordnet.

    Dabei kann ein Platz nur einen Studenten enthalten (daher ist das der
    primary_key). Eine Praxis kann zu einem BP-Zeitraum natürlich nur einen
    Platz haben (daher das unique_together).

    Dazu kommen die Attribute 'manuell' und 'kommentar'.
    """
    class Meta:
        verbose_name = 'BP-Platz'
        verbose_name_plural = 'BP-Plätze'
        unique_together = ('praxis', 'bp_zeitraum')
        ordering = ['bp_zeitraum']

    def get_absolute_url(self):
        return reverse('bp_cupid:bpplatz_detail', args=[str(self.student.id)])

    def __str__(self):
        man_text = 'manuell' if self.manuell else 'automatisch'
        return 'BP: {student} bei {praxis} in {zeitraum} ({manuell})'.format(
            student=self.student,
            praxis=self.praxis,
            zeitraum=self.bp_zeitraum,
            manuell=man_text,
        )

    student = models.OneToOneField(
        Student,
        primary_key=True,
        related_name='%(class)s'
    )
    bp_zeitraum = models.ForeignKey(
        BPZeitraum,
        related_name='bp_plaetze',
        verbose_name='BP-Zeitraum',
    )

    @property
    def anfang(self):
        return self.bp_zeitraum.anfang

    @property
    def ende(self):
        return self.bp_zeitraum.ende

    @property
    def zeitspanne(self):
        delta = self.ende - self.anfang
        return delta.days + 1

    # andere Attribute
    manuell = models.BooleanField(
        default=False,
        help_text=(
            'Wenn aktiviert, dann wird der Platz bei der automatischen'
            ' Platzvergabe nicht gelöscht.'
        ),
    )

    # Änderungsgeschichte:
    history = HistoricalRecords()

    def gewicht(self):
        """
        Gibt das Gewicht dieses BP-Platzes zurück.
        """
        return Gewicht.objects.get(
            student=self.student,
            praxis=self.praxis,
        )

    def berechne_bp_platzgewicht(self):
        """
        Berechnet das Platzgewicht und speichert es ab.
        """
        g = Gewicht.berechne(
            student=self.student,
            praxis=self.praxis
        )
        g.save()

    @classmethod
    def vergib_bp_platz(cls, s_id, p_id, z_id=None):
        """
        Vergibt einen BP-Platz an den erstbesten BP-Zeitraum an Studenten s_id
        und Praxis p_id.
        """
        student = Student.objects.get(id=s_id)
        praxis = Praxis.objects.get(id=p_id)
        if z_id:
            bp_zeitraum = BPZeitraum.objects.get(id=z_id)
        else:
            bp_zeitraum = praxis.erster_freier_bp_zeitraum()

        bp_platz = cls(
            student=student,
            praxis=praxis,
            bp_zeitraum=bp_zeitraum,
            manuell=False
        )

        # Zur Sicherheit rufen wir vor dem Speichern nochmal full_clean() auf,
        # damit wir lieber eine Exception schmeißen als falsche Plätze zu
        # vergeben:

        bp_platz.full_clean()
        logger.debug('Vergebe BP-Platz: {}'.format(bp_platz))
        bp_platz.save()

        return bp_platz

    @classmethod
    def tausche(cls, p, q):
        logger.debug('Tausche {} mit {}'.format(p, q))

        student1, praxis1, bp_zeitraum1 = (
                p.student.id,
                p.praxis.id,
                p.bp_zeitraum.id
            )
        student2, praxis2, bp_zeitraum2 = (
                q.student.id,
                q.praxis.id,
                q.bp_zeitraum.id
            )

        p.delete()
        q.delete()

        p_neu = cls.vergib_bp_platz(student1, praxis2, bp_zeitraum2)
        q_neu = cls.vergib_bp_platz(student2, praxis1, bp_zeitraum1)

        logger.debug(
            'Getauscht! Jetzt haben wir {} und {}'.format(
                p_neu, q_neu
            )
        )

    def clean(self):
        try:
            if self.check_alles_wichtige_gleich():
                return
            else:
                self.check_bp_zeitraum_in_bp_zeitraeume_der_praxis()
                self.check_bp_zeitraum_in_freie_bp_zeitraeume_der_praxis()
                self.check_platzbegrenzung_eingehalten()
        except (Praxis.DoesNotExist, BPZeitraum.DoesNotExist):
            """
            Wenn wir einen BP-Platz bearbeiten und keine Praxis oder BPZeitraum
            angegeben ist, dann wirft clean() eine abstürzende Exception,
            obwohl Django eigentlich einfach nur "Dieses Feld ist erforderlich"
            anzeigen müsste.
            Diese Exceptions fangen wir hier ab und machen gar nichts. Dann tut
            Django auch was es soll.
            """
            pass

    def check_alles_wichtige_gleich(self):
        """
        Wenn sich zwischen dem alten und neuen BP-Platz nichts geändert hat und
        wir nur unwichtigen Kram (manuell oder kommentar) ändern, dann brauchen
        wir die restlichen Checks nicht.
        """
        try:
            alter_bp_platz = BPPlatz.objects.get(pk=self.pk)
            alles_gleich = all(
                [
                    alter_bp_platz.bp_zeitraum == self.bp_zeitraum,
                    alter_bp_platz.praxis == self.praxis,
                    alter_bp_platz.student == self.student,
                ]
            )

            if alles_gleich:
                return True

        except BPPlatz.DoesNotExist:
            pass

        return False

    def check_bp_zeitraum_in_bp_zeitraeume_der_praxis(self):
        if self.bp_zeitraum not in self.praxis.bp_zeitraeume.all():
            raise ValidationError(
                mark_safe(
                    (
                        '{praxis} bietet im BP-Zeitraum {zeitraum} '
                        'keinen BP-Platz an. '
                        'Probiere folgende:'
                        '<ul>{zeitraeume}</ul>'
                    ).format(
                        praxis=self.praxis,
                        zeitraum=self.bp_zeitraum,
                        zeitraeume=''.join(
                            [
                                '<li>{}</li>'.format(z)
                                for z in self.praxis.freie_bp_zeitraeume.all()
                            ]
                        )
                    )
                )
            )

    def check_bp_zeitraum_in_freie_bp_zeitraeume_der_praxis(self):
        if self.bp_zeitraum not in self.praxis.freie_bp_zeitraeume.all():
            raise ValidationError(
                mark_safe(
                    (
                        'Der BP-Zeitraum {zeitraum} '
                        'bei Praxis {praxis} ist schon belegt. '
                        'Probiere folgende: <ul>{zeitraeume}</ul>'
                    ).format(
                        praxis=self.praxis,
                        zeitraum=self.bp_zeitraum,
                        zeitraeume=''.join(
                            [
                                '<li>{}</li>'.format(z)
                                for z in self.praxis.freie_bp_zeitraeume.all()
                            ]
                        )
                    )
                )
            )

    def check_platzbegrenzung_eingehalten(self):
        verw_zr = self.bp_zeitraum.bp_block.bp_verwaltungszeitraum
        platzbegrenzung_existiert = self.praxis.bpplatzbegrenzung.filter(
            bp_verwaltungszeitraum=verw_zr
        ).exists()
        if platzbegrenzung_existiert:
            # Überprüfe die evtl. BP-Platzbegrenzung
            pgrenze = self.praxis.bpplatzbegrenzung.get(
                bp_verwaltungszeitraum=verw_zr
            )
            anzahl_bp_plaetze = self.praxis.bpplatz_related.filter(
                bp_zeitraum__bp_block__bp_verwaltungszeitraum=verw_zr,
            ).count()
            if pgrenze.anzahl <= anzahl_bp_plaetze:
                raise ValidationError(
                    u'Maximale Platzgrenze für das BP ist erreicht.'
                )


class PJPlatz(Platz):
    class Meta:
        verbose_name = 'PJ-Platz'
        verbose_name_plural = 'PJ-Plätze'
        unique_together = (
            # Eine Praxis kann in einem PJ-Zeitraum nur einen Studenten
            # betreuen:
            ('praxis', 'pj_zeitraum'),
            # Ein Student kann in einem PJ-Zeitraum nur in einer Praxis sein:
            ('student', 'pj_zeitraum')
        )
        ordering = ['pj_zeitraum']

    def get_absolute_url(self):
        return reverse('bp_cupid:pjplatz_detail', args=[str(self.id)])

    def __str__(self):
        return 'PJ: {student} bei {praxis} in {zeitraum}'.format(
            student=self.student,
            praxis=self.praxis,
            zeitraum=self.pj_zeitraum,
        )

    """
    Ein Student kann ein PJ-Tertial (bei uns einen PJZeitraum) splitten. Also
    kann ein Student mehrere PJ-Plätze haben. Daher ist student ein ForeignKey
    und kein OneToOneField.
    """
    student = models.ForeignKey(
        Student,
        related_name='%(class)s'
    )
    pj_zeitraum = models.ForeignKey(
        PJZeitraum,
        related_name='pj_plaetze',
        verbose_name='PJ-Zeitraum',
    )

    @property
    def anfang(self):
        return self.pj_zeitraum.anfang

    @property
    def ende(self):
        return self.pj_zeitraum.ende

    @property
    def zeitspanne(self):
        delta = self.ende - self.anfang
        return delta.days + 1

    def clean(self):
        """
        Wenn sich zwischen dem alten und neuen PJ-Platz nichts geändert hat und
        wir nur unwichtigen Kram (kommentar) ändern, dann brauchen wir die
        restlichen Checks nicht.
        """
        try:
            alter_pj_platz = PJPlatz.objects.get(pk=self.pk)
            if all(
                    [
                        alter_pj_platz.pj_zeitraum == self.pj_zeitraum,
                        alter_pj_platz.praxis == self.praxis,
                        alter_pj_platz.student == self.student,
                    ]
                    ):
                return
        except PJPlatz.DoesNotExist:
            pass

        moegliche_zeitraeume = self.praxis.freie_pj_zeitraeume.all()
        moegliche_zeitraeume_str = ', '.join(
            map(str, self.praxis.freie_pj_zeitraeume.all())
        )

        if self.pj_zeitraum in self.praxis.belegte_pj_zeitraeume.all():
            fehler_schon_belegt = (
                'Der PJ-Zeitraum {zeitraum} bei Praxis {praxis} '
                'ist schon belegt. '
            )
            if moegliche_zeitraeume.exists():
                raise ValidationError(
                    (
                         fehler_schon_belegt +
                         'Probiere folgende: {zeitraeume}'
                    ).format(
                        praxis=self.praxis,
                        zeitraum=self.pj_zeitraum,
                        zeitraeume=moegliche_zeitraeume_str,
                    )
                )
            else:
                raise ValidationError(
                    (
                        fehler_schon_belegt +
                        'Die Praxis hat keine freien PJ-Zeiträume.'
                    ).format(
                        praxis=self.praxis,
                        zeitraum=self.pj_zeitraum,
                    )
                )

        elif self.pj_zeitraum not in self.praxis.freie_pj_zeitraeume.all():
            fehler_nicht_angeboten = (
                'Der PJ-Zeitraum {zeitraum} bei Praxis {praxis} '
                'wird von dieser gar nicht angeboten. '
            )
            if moegliche_zeitraeume.exists():
                raise ValidationError(
                    (
                        fehler_nicht_angeboten +
                        'Probiere folgende: {zeitraeume}'
                    ).format(
                        praxis=self.praxis,
                        zeitraum=self.pj_zeitraum,
                        zeitraeume=moegliche_zeitraeume_str,
                    )
                )
            else:
                raise ValidationError(
                    (
                        fehler_nicht_angeboten +
                        'Die Praxis hat keine freien PJ-Zeiträume.'
                    ).format(
                        praxis=self.praxis,
                        zeitraum=self.pj_zeitraum,
                    )
                )
