from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from django.forms import (
    HiddenInput,
    ModelForm,
    NumberInput,
    Select,
    Textarea,
    ValidationError,
)

from django_ace import AceWidget

from django_auth_ldap3.backends import LDAPBackend
from django_auth_ldap3.conf import settings

from .models import (
    Abrechnungszeitraum,
    BPBlock,
    BPPlatz,
    BPVerwaltungszeitraum,
    Evaluation,
    PJBlock,
    PJVerwaltungszeitraum,
    Praxis,
    Student,
    Vorlage,
    ZusatzinfoPraxis,
)


import logging
logger = logging.getLogger(__name__)


class BPAuthenticationForm(AuthenticationForm):
    """
    Unser eigenes Authentifizierungsformular für das BP.
    """
    def clean(self):
        """
        Wenn sich ein Student einloggen will, müssen wir ein lokales
        Studentenobjekt erzeugen, in der wir die BP-Vorlieben speichern. Die
        erforderlichen Daten holen wir uns mittels LDAP vom Rechenzentrum.
        """
        cleaned_data = super().clean()

        username = cleaned_data.get('username')
        password = cleaned_data.get('password')

        ldap_backend = LDAPBackend()
        ldap_user = ldap_backend.bind_ldap_user(username, password)

        # Falls kein LDAP User existiert, probieren wir lokal weiter:
        if not ldap_user:
            return cleaned_data

        # der lokale User müsste schon erzeugt worden sein
        user = User.objects.get(username=username)

        connection = ldap_user.connection
        search_filter = '({}={})'.format(settings.UID_ATTRIB, username)

        # so heißen die Attribute auf dem LDAP-Server:
        mat_nr_attr = 'sos-mtknr'
        gender_attr = 'uniRGender'

        attributes = ldap_backend.search_ldap(
            connection,
            search_filter,
            attributes=[mat_nr_attr, gender_attr],
            size_limit=1,
        )

        mat_nr = int(attributes[mat_nr_attr])
        weiblich = attributes[gender_attr] == 'W'

        """
        Hier holen wir das lokale Studentenobjekt und speichern die relevanten
        Daten. Leider sind ein paar Daten wie Name und E-Mail-Adresse
        redundant, aber was willste machen.
        """
        try:
            student = Student.objects.get(mat_nr=mat_nr)
            student.user = user
            student.name = user.last_name
            student.vorname = user.first_name
            student.email = user.email
            student.weiblich = weiblich
            student.save()
        except Student.DoesNotExist:
            raise ValidationError(
                'Nicht zugelassen.'
            )

        return cleaned_data


class VorlagenForm(ModelForm):
    class Meta:
        model = Vorlage
        fields = ['token', 'text']
        widgets = {
            'text': AceWidget(
                mode='django',
                theme='solarized_light',
                width='900px',
                height='400px',
                wordwrap=True,
            ),
        }


def bootstrap_field(f, **kwargs):
    field = f.formfield(**kwargs)
    if field and type(field.widget) in [Textarea, NumberInput, Select]:
        field.widget.attrs['class'] = 'form-control'
        if f.name.startswith('kommentar_'):
            field.widget.attrs['rows'] = '2'
    if field and type(field.widget) == NumberInput:
        field.widget.attrs['min'] = '1'
        field.widget.attrs['max'] = '6'
    return field


class EvaluationForm(ModelForm):
    formfield_callback = bootstrap_field

    class Meta:
        model = Evaluation
        fields = '__all__'


class StudentForm(ModelForm):
    class Meta:
        model = Student
        fields = (
            'bp_verwaltungszeitraum',
            'vorname',
            'name',
            'mat_nr',
            'weiblich',
            'email',
            'telefonnummer',
            'hat_fragebogen_ausgefuellt',
            'hat_seminar_besucht',
            'ist_haertefall',
            'note_bp',
            'note_klausur',
            'gewichtung_kinder',
            'gewichtung_sono',
            'gewichtung_sport',
            'gewichtung_kompl',
            'gewichtung_bundeswehr',
            'entfernte_praxis_wenn_unterkunft',
            'fs_und_fahrzeug',
            'priv_unterkunft',
            'landkreise',
            'bevorzugte_praxen',
            'besondere_praxiskriterien',
            'sonstiges',
            'interne_notizen',
        )


class PraxisForm(ModelForm):
    class Meta:
        model = Praxis
        fields = (
            'anrede',
            'vorname',
            'name',
            'sortierschluessel',
            'adresse',
            'plz',
            'ort',
            'position',
            'ist_vip',
            'landkreis',
            'telefon',
            'telefax',
            'homepage',
            'email',
            'ist_aktiv',
            'hat_didaktikschulung_besucht',
            'beginn_bp_lehrtaetigkeit',
            'hat_bp_urkunde_erhalten',
            'beginn_pj_lehrtaetigkeit',
            'hat_pj_urkunde_erhalten',
            'unterkunft',
            'kinder',
            'sono',
            'sport',
            'kompl',
            'bundeswehr',
            'ist_landarztpraxis',
            'freie_unterkunft',
            'billige_unterkunft',
            'nur_mit_auto',
            'erg_taetigkeiten',
            'andere_kriterien',
            'erg_unterbringung',
            'sonstiges',
            'interne_notizen',
        )


class BPPlatzForm(ModelForm):
    class Meta:
        model = BPPlatz
        fields = (
            'student',
            'praxis',
            'bp_zeitraum',
            'manuell',
            'kommentar',
        )


class BPBlockForm(ModelForm):
    class Meta:
        model = BPBlock
        fields = [
            'name',
            'bp_verwaltungszeitraum',
        ]
        """
        Wir setzen 'bp_verwaltungszeitraum' auf HiddenInput, damit es nicht
        explizit angezeigt, aber dennoch mitgeschickt wird. Damit kann Django
        automatisch überprüfen, ob schon ein BP-Block mit diesem Namen in dem
        BP-Verwaltungszeitraum existiert.

        Würde 'fields' nur aus ['name'] bestehen, dann führte das zu einem
        IntegrityError, weil die unique_together-Bedingung nicht überprüft
        werden kann.
        """
        widgets = {
            'bp_verwaltungszeitraum': HiddenInput(),
        }


class PJBlockForm(ModelForm):
    class Meta:
        model = PJBlock
        fields = [
            'name',
            'pj_verwaltungszeitraum',
        ]
        """
        Wir setzen 'pj_verwaltungszeitraum' auf HiddenInput, damit es nicht
        explizit angezeigt, aber dennoch mitgeschickt wird. Damit kann Django
        automatisch überprüfen, ob schon ein PJ-Block mit diesem Namen in dem
        BP-Verwaltungszeitraum existiert.

        Würde 'fields' nur aus ['name'] bestehen, dann führte das zu einem
        IntegrityError, weil die unique_together-Bedingung nicht überprüft
        werden kann.
        """
        widgets = {
            'pj_verwaltungszeitraum': HiddenInput(),
        }


class BPVerwaltungszeitraumForm(ModelForm):
    class Meta:
        model = BPVerwaltungszeitraum
        fields = '__all__'


class PJVerwaltungszeitraumForm(ModelForm):
    class Meta:
        model = PJVerwaltungszeitraum
        fields = '__all__'


class ZusatzinfoForm(ModelForm):
    class Meta:
        model = ZusatzinfoPraxis
        fields = '__all__'


class AbrechnungszeitraumForm(ModelForm):
    class Meta:
        model = Abrechnungszeitraum
        fields = [
            'name',
            'bp_verwaltungszeitraum',
        ]
        widgets = {
            'bp_verwaltungszeitraum': HiddenInput(),
        }
