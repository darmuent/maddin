from calendar import Calendar, mdays, isleap
import datetime

from .models import (
    Mitarbeiter,
    BPVerwaltungszeitraum,
)


def installation_notwendig(current_user):
    """
    Überprüft, ob mindestens ein BP-Verwaltungszeitraum und zum aktuellen
    Benutzer ein Mitarbeiter existiert.
    """
    return not (
        BPVerwaltungszeitraum.objects.exists()
        and
        Mitarbeiter.objects.filter(user=current_user).exists()
    )


ONEDAY = datetime.timedelta(days=1)


class CupidCalendar(Calendar):
    def iterdates(self, start, end, including_end=True):
        if start > end:
            raise ValueError(
                "start can't be greater than end."
            )

        date = start
        while date < end:
            yield date

            try:
                date += ONEDAY
            except OverflowError:
                # Adding one day could fail after datetime.MAXYEAR
                break

        if including_end:
            yield date

    def iterweekdates(self, start, end):
        # Go back to the beginning of the week
        start = self.recent_firstweekday(start)
        # Set end to the next "sunday" (= last day of week)
        end = self.next_lastweekday(end)
        return self.iterdates(start, end)

    def recent_firstweekday(self, date):
        days = (date.weekday() - self.firstweekday) % 7
        return date - datetime.timedelta(days=days)

    def next_lastweekday(self, date):
        lastweekday = ((self.firstweekday - 1) % 7)
        days = lastweekday - date.weekday()
        return date + datetime.timedelta(days=days)

    def itermonthsdates(self, start, end):
        first_day = datetime.date(start.year, start.month, 1)
        # Go back to the beginning of the week
        days = (start.weekday() - self.firstweekday) % 7
        first_day -= datetime.timedelta(days=days)

        last_day = datetime.date(end.year, end.month, mdays[end.month])
        if isleap(end.year) and end.month == 2:
            last_day += ONEDAY

        last_day_of_week = ((self.firstweekday - 1) % 7)
        days = last_day_of_week - end.weekday()
        last_day += datetime.timedelta(days=days)

        return self.iterdates(first_day, last_day)
