from django.contrib import admin
from django.core.urlresolvers import reverse
from django.shortcuts import redirect
from django.utils.http import urlencode

from simple_history.admin import SimpleHistoryAdmin

from .models import (
    Abrechnungsdetail,
    BPBlock,
    Evaluation,
    Gewicht,
    Landkreis,
    Mitarbeiter,
    BPPlatz,
    BPPlatzbegrenzung,
    Praxis,
    Student,
    BPVerwaltungszeitraum,
    Vorlage,
    BPZeitraum,
    ZusatzinfoPraxis,
)
from .forms import VorlagenForm


@admin.register(Landkreis)
class LandkreisAdmin(admin.ModelAdmin):
    list_display = ('name', 'plz_von', 'plz_bis', 'orte')
    list_display_links = ('name',)
    ordering = ('plz_von',)


@admin.register(BPVerwaltungszeitraum)
class BPVerwaltungszeitraumAdmin(admin.ModelAdmin):
    list_display = (
        'name',
        'anfang',
        'ende',
        'plaetze_fuer_studenten_einsehbar',
    )
    list_editable = ('plaetze_fuer_studenten_einsehbar', )
    ordering = ('anfang', )


@admin.register(BPPlatz)
class BPPlatzAdmin(SimpleHistoryAdmin):
    list_display = ('student', 'praxis', 'bp_zeitraum', 'manuell', 'kommentar')
    ordering = ('student__name', )

    def change_view(self, request, object_id, form_url='', extra_context=None):
        praxis_id = request.GET.get('praxis', None)
        bp_zeitraum_id = request.GET.get('bp_zeitraum', None)
        manuell = request.GET.get('manuell', False)

        if praxis_id and bp_zeitraum_id:
            BPPlatz.objects.get(student=object_id).delete()
            d = {
                'student': object_id,
                'praxis': praxis_id,
                'bp_zeitraum': bp_zeitraum_id,
                'manuell': manuell,
            }
            return redirect(
                '%s?%s' % (
                    reverse('admin:bp_cupid_bpplatz_add'),
                    urlencode(d)
                )
            )
        else:
            return super(BPPlatzAdmin, self).change_view(
                request, object_id, form_url, extra_context=extra_context
            )
    search_fields = ['student__vorname', 'student__name', 'student__mat_nr']


@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = (
        'mat_nr',
        'vorname', 'name',
        'weiblich',
        'bp_verwaltungszeitraum',
        'gewichtung_kinder',
        'gewichtung_sono',
        'gewichtung_sport',
        'gewichtung_kompl',
        'gewichtung_bundeswehr',
        'fs_und_fahrzeug',
        'priv_unterkunft',
        'adresse_priv_unterkunft',
        'sonstiges',
        'extern',
        'hat_fragebogen_ausgefuellt',
    )
    list_editable = ('weiblich', 'bp_verwaltungszeitraum')
    filter_horizontal = (
        'landkreise',
        'bevorzugte_praxen',
        'abgeneigte_praxen',
    )
    search_fields = ['vorname', 'name', 'mat_nr']


@admin.register(BPZeitraum)
class BPZeitraumAdmin(admin.ModelAdmin):
    list_display = ('bp_block', 'anfang', 'ende')
    list_display_links = ('anfang',)
    readonly_fields = ('ueberlappende',)
    ordering = ('anfang',)


class BPZeitraumInline(admin.TabularInline):
    model = BPZeitraum
    readonly_fields = ('ueberlappende',)
    extra = 1


@admin.register(BPBlock)
class BPBlockAdmin(admin.ModelAdmin):
    list_display = ('name', 'bp_verwaltungszeitraum', 'zeiten', 'kapazitaet')
    readonly_fields = ('kapazitaet',)
    ordering = ('name',)
    inlines = [
        BPZeitraumInline,
    ]


class BPPlatzbegrenzungInline(admin.TabularInline):
    model = BPPlatzbegrenzung
    extra = 1


@admin.register(Praxis)
class PraxisAdmin(admin.ModelAdmin):
    list_display = (
        'anrede',
        'vorname',
        'name',
        'ist_aktiv',
        'hat_didaktikschulung_besucht',
        'landkreis',
        'lehre_bp',
        'lehre_pj',
        'kinder',
        'sono',
        'sport',
        'kompl',
        'erg_taetigkeiten',
        'andere_kriterien',
        'nur_mit_auto',
        'freie_unterkunft',
        'billige_unterkunft',
        'unterkunft',
        'erg_unterbringung',
        'sonstiges',
    )
    list_display_links = ('name',)
    readonly_fields = ('freie_bp_zeitraeume', 'belegte_bp_zeitraeume')
    list_editable = ('ist_aktiv', 'hat_didaktikschulung_besucht')
    ordering = ('name',)
    filter_horizontal = (
        'bp_zeitraeume',
        'freie_bp_zeitraeume',
        'belegte_bp_zeitraeume'
    )
    search_fields = ['vorname', 'name']
    inlines = [
        BPPlatzbegrenzungInline,
    ]


@admin.register(Gewicht)
class GewichtAdmin(admin.ModelAdmin):
    list_display = ('student', 'praxis', 'wert', 'umgebrochener_kommentar')
    ordering = ('student', 'praxis')
    search_fields = ['student__vorname', 'student__name', 'student__mat_nr']


@admin.register(Mitarbeiter)
class MitarbeiterAdmin(admin.ModelAdmin):
    list_display = ('user', 'akt_bp_verw_zeitraum')
    list_editable = ('akt_bp_verw_zeitraum', )


@admin.register(Vorlage)
class VorlagenAdmin(admin.ModelAdmin):
    list_display = ('token', 'text')
    ordering = ('token', )
    form = VorlagenForm
    search_fields = ['token', 'text']


@admin.register(ZusatzinfoPraxis)
class ZusatzinfoPraxisAdmin(admin.ModelAdmin):
    list_display = ('praxis', 'bp_verwaltungszeitraum', 'text')
    list_display_links = ('praxis',)
    ordering = ('-bp_verwaltungszeitraum__anfang', 'praxis')
    search_fields = [
        'praxis__name',
        'praxis__vorname',
        'praxis__ort',
        'text',
    ]


@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    list_display = ('bp_platz', 'eval_user', 'datum')
    list_display_links = ('bp_platz', )
    readonly_fields = ('datum',)
    search_fields = [
        'bp_platz__student__vorname',
        'bp_platz__student__name',
        'bp_platz__student__mat_nr',
        'bp_platz__praxis__vorname',
        'bp_platz__praxis__name',
    ]
    ordering = ('-datum', 'bp_platz__student__name')


@admin.register(Abrechnungsdetail)
class AbrechnungsdetailAdmin(SimpleHistoryAdmin):
    list_display = (
        'praxis',
        'abrechnungszeitraum',
        'erstellt',
        'eingegangen',
        'weiterleitung_an_df',
        'buchung_erfolgt',
        'erinnerung_an_la',
    )
    list_display_links = ('praxis',)
    ordering = ('praxis', 'bp_verwaltungszeitraum__anfang')
