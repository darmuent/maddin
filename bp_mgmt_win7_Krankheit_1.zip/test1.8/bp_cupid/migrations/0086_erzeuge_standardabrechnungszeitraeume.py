# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations


def erzeuge_standardabrechnungszeitraeume(apps, schema_editor):
    BPVerwaltungszeitraum = apps.get_model('bp_cupid', 'BPVerwaltungszeitraum')
    Abrechnungszeitraum = apps.get_model('bp_cupid', 'Abrechnungszeitraum')
    for bp_verwzr in BPVerwaltungszeitraum.objects.all():
        abr_zr = Abrechnungszeitraum(bp_verwaltungszeitraum=bp_verwzr)
        abr_zr.save()


def loesche_abrechnungszeitraeume(apps, schema_editor):
    Abrechnungszeitraum = apps.get_model('bp_cupid', 'Abrechnungszeitraum')
    Abrechnungszeitraum.objects.all().delete()


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0085_abrechnungszeitraum'),
    ]

    operations = [
        migrations.RunPython(
            erzeuge_standardabrechnungszeitraeume,
            reverse_code=loesche_abrechnungszeitraeume,
        ),
    ]
