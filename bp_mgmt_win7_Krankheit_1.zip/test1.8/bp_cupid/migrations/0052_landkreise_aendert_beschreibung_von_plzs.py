# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0051_historicalstudent'),
    ]

    operations = [
        migrations.AlterField(
            model_name='landkreis',
            name='plz_bis',
            field=models.IntegerField(verbose_name='PLZ bis', default=0),
        ),
        migrations.AlterField(
            model_name='landkreis',
            name='plz_von',
            field=models.IntegerField(verbose_name='PLZ von', default=0),
        ),
    ]
