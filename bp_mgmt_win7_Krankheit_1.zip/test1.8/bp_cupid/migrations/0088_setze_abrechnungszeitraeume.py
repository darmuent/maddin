# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations


def setze_abrechnungszeitraeume(apps, schema_editor):
    BPVerwaltungszeitraum = apps.get_model('bp_cupid', 'BPVerwaltungszeitraum')
    for bp_verwzr in BPVerwaltungszeitraum.objects.all():
        abr_zr = bp_verwzr.abrechnungszeitraum.first()
        for abr_detail in bp_verwzr.abrechnungsdetail.all():
            abr_detail.abrechnungszeitraum = abr_zr
            abr_detail.save()


def loesche_abrechnungszeitraeume_von_abrechnungsdetail(apps, schema_editor):
    Abrechnungsdetail = apps.get_model('bp_cupid', 'Abrechnungsdetail')
    for abr_detail in Abrechnungsdetail.objects.all():
        abr_detail.abrechnungszeitraum = None
        abr_detail.save()


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0087_add_fk_abrechnungszeitraum_to_abrechnungsdetail'),
    ]

    operations = [
        migrations.RunPython(
            setze_abrechnungszeitraeume,
            reverse_code=loesche_abrechnungszeitraeume_von_abrechnungsdetail,
        ),
    ]
