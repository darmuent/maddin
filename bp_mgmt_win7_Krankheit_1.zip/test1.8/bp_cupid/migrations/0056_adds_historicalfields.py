# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0055_student_interne_notizen'),
    ]

    operations = [
        migrations.AddField(
            model_name='historicalabrechnungsdetail',
            name='history_change_reason',
            field=models.CharField(max_length=100, null=True),
        ),
        migrations.AddField(
            model_name='historicalplatz',
            name='history_change_reason',
            field=models.CharField(max_length=100, null=True),
        ),
        migrations.AddField(
            model_name='historicalstudent',
            name='history_change_reason',
            field=models.CharField(max_length=100, null=True),
        ),
        migrations.AddField(
            model_name='historicalzusatzinfopraxis',
            name='history_change_reason',
            field=models.CharField(max_length=100, null=True),
        ),
    ]
