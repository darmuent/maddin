# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0063_praxis_beginn_der_lehrtaetigkeit'),
    ]

    operations = [
        # Das hier wurde vom autodetector produziert:

        # migrations.CreateModel(
        #     name='BPVerwaltungszeitraum',
        #     fields=[
        #         ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
        #         ('name', models.CharField(max_length=50, unique=True)),
        #         ('anfang', models.DateField()),
        #         ('ende', models.DateField()),
        #         ('plaetze_fuer_studenten_einsehbar', models.BooleanField(verbose_name='Plätze sind für Studenten einsehbar', default=False, help_text='Wenn aktiviert, dann werden die zugewiesenen Plätze auf der Startseite der Studenten angezeigt.')),
        #         ('anzeige_fuer_fragebogen', models.TextField(verbose_name='Anzeige für den Fragebogen', blank=True, default='', help_text='So wird der dem Studenten zugeordnete BP-Verwaltungszeitraum in der Überschrift des Fragebogens angezeigt. Für den Verwaltungszeitraum „WS1617“ könnte dieser Text bspw. „WS 2016-17 und SS 2017“ sein.')),
        #     ],
        #     options={
        #         'verbose_name': 'BP-Verwaltungszeitraum',
        #         'verbose_name_plural': 'BP-Verwaltungszeiträume',
        #     },
        # ),

        # Besser wäre es, wenn wir Verwaltungszeitraum einfach zu
        # BPVerwaltungszeitraum umbenennen, anstatt das Model neu zu erstellen,
        # umzukopieren und das alte zu löschen.

        migrations.RenameModel(
            old_name='Verwaltungszeitraum',
            new_name='BPVerwaltungszeitraum',
        ),
        migrations.AlterModelOptions(
            name='BPVerwaltungszeitraum',
            options={
                'verbose_name': 'BP-Verwaltungszeitraum',
                'verbose_name_plural': 'BP-Verwaltungszeiträume',
            },
        ),
        # Hier ändern wir nur den help_text:
        migrations.AlterField(
            model_name='BPVerwaltungszeitraum',
            name='anzeige_fuer_fragebogen',
            field=models.TextField(
                verbose_name='Anzeige für den Fragebogen',
                blank=True,
                default='',
                help_text='So wird der dem Studenten zugeordnete BP-Verwaltungszeitraum in der Überschrift des Fragebogens angezeigt. Für den Verwaltungszeitraum „WS1617“ könnte dieser Text bspw. „WS 2016-17 und SS 2017“ sein.'),
        ),

        # Bevor wir die Felder umbenennen, müssen wir erst die
        # Fremdschlüsseleinträge anpassen. Diese zeigen ja jetzt auf
        # BPVerwaltungszeitraum!

        migrations.AlterField(
            model_name='historicalabrechnungsdetail',
            name='verwaltungszeitraum',
            field=models.ForeignKey(
                blank=True,
                null=True,
                related_name='+',
                on_delete=django.db.models.deletion.DO_NOTHING,
                to='bp_cupid.BPVerwaltungszeitraum',
                db_constraint=False),
        ),

        # Und dann benennen wir das Feld um:
        migrations.RenameField(
            model_name='historicalabrechnungsdetail',
            old_name='verwaltungszeitraum',
            new_name='bp_verwaltungszeitraum',
        ),

        # migrations.RemoveField(
        #     model_name='historicalabrechnungsdetail',
        #     name='verwaltungszeitraum',
        # ),
        # migrations.AddField(
        #     model_name='historicalabrechnungsdetail',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.BPVerwaltungszeitraum', db_constraint=False),
        # ),

        migrations.AlterField(
            model_name='historicalstudent',
            name='verwaltungszeitraum',
            field=models.ForeignKey(
                blank=True,
                null=True,
                related_name='+',
                on_delete=django.db.models.deletion.DO_NOTHING,
                to='bp_cupid.BPVerwaltungszeitraum',
                db_constraint=False),
        ),
        migrations.RenameField(
            model_name='historicalstudent',
            old_name='verwaltungszeitraum',
            new_name='bp_verwaltungszeitraum',
        ),

        # migrations.RemoveField(
        #     model_name='historicalstudent',
        #     name='verwaltungszeitraum',
        # ),
        # migrations.AddField(
        #     model_name='historicalstudent',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.BPVerwaltungszeitraum', db_constraint=False),
        # ),

        migrations.AlterField(
            model_name='historicalzusatzinfopraxis',
            name='verwaltungszeitraum',
            field=models.ForeignKey(
                blank=True,
                null=True,
                related_name='+',
                on_delete=django.db.models.deletion.DO_NOTHING,
                to='bp_cupid.BPVerwaltungszeitraum',
                db_constraint=False),
        ),
        migrations.RenameField(
            model_name='historicalzusatzinfopraxis',
            old_name='verwaltungszeitraum',
            new_name='bp_verwaltungszeitraum',
        ),

        # migrations.RemoveField(
        #     model_name='historicalzusatzinfopraxis',
        #     name='verwaltungszeitraum',
        # ),
        # migrations.AddField(
        #     model_name='historicalzusatzinfopraxis',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(blank=True, null=True, related_name='+', on_delete=django.db.models.deletion.DO_NOTHING, to='bp_cupid.BPVerwaltungszeitraum', db_constraint=False),
        # ),

        migrations.AlterField(
            model_name='mitarbeiter',
            name='akt_verw_zeitraum',
            field=models.ForeignKey(
                verbose_name='aktueller BP-Verwaltungszeitraum',
                help_text='Bei allen Ansichten werden nur Blöcke und Zeiträume des aktuellen Bp-Verwaltungszeitraums angezeigt.',
                to='bp_cupid.BPVerwaltungszeitraum'),
        ),
        migrations.RenameField(
            model_name='mitarbeiter',
            old_name='akt_verw_zeitraum',
            new_name='akt_bp_verw_zeitraum',
        ),

        # migrations.RemoveField(
        #     model_name='mitarbeiter',
        #     name='akt_verw_zeitraum',
        # ),
        # migrations.AddField(
        #     model_name='mitarbeiter',
        #     name='akt_bp_verw_zeitraum',
        #     field=models.ForeignKey(verbose_name='aktueller BP-Verwaltungszeitraum', default=1, help_text='Bei allen Ansichten werden nur Blöcke und Zeiträume des aktuellen Bp-Verwaltungszeitraums angezeigt.', to='bp_cupid.BPVerwaltungszeitraum'),
        # ),

        migrations.AlterField(
            model_name='student',
            name='verwaltungszeitraum',
            field=models.ForeignKey(to='bp_cupid.BPVerwaltungszeitraum'),
        ),
        migrations.RenameField(
            model_name='student',
            old_name='verwaltungszeitraum',
            new_name='bp_verwaltungszeitraum',
        ),

        # migrations.RemoveField(
        #     model_name='student',
        #     name='verwaltungszeitraum',
        # ),
        # migrations.AddField(
        #     model_name='student',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(default=0, to='bp_cupid.BPVerwaltungszeitraum'),
        #     preserve_default=False,
        # ),

        # Die AlterUniqueTogether-Migrations wird von RenameField übernommen,
        # darum brauchen wir uns also nicht kümmern.

        migrations.AlterField(
            model_name='abrechnungsdetail',
            name='verwaltungszeitraum',
            field=models.ForeignKey(
                related_name='abrechnungsdetail',
                to='bp_cupid.BPVerwaltungszeitraum'
            ),
        ),
        migrations.RenameField(
            model_name='abrechnungsdetail',
            old_name='verwaltungszeitraum',
            new_name='bp_verwaltungszeitraum',
        ),

        # migrations.AlterUniqueTogether(
        #     name='abrechnungsdetail',
        #     unique_together=set([('bp_verwaltungszeitraum', 'praxis')]),
        # ),
        # migrations.RemoveField(
        #     model_name='abrechnungsdetail',
        #     name='verwaltungszeitraum',
        # ),
        # migrations.AddField(
        #     model_name='abrechnungsdetail',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(default=0, related_name='abrechnungsdetail', to='bp_cupid.BPVerwaltungszeitraum'),
        #     preserve_default=False,
        # ),

        migrations.AlterField(
            model_name='block',
            name='verwaltungszeitraum',
            field=models.ForeignKey(
                related_name='bloecke',
                to='bp_cupid.BPVerwaltungszeitraum'
            ),
        ),
        migrations.RenameField(
            model_name='block',
            old_name='verwaltungszeitraum',
            new_name='bp_verwaltungszeitraum',
        ),

        # migrations.AlterUniqueTogether(
        #     name='block',
        #     unique_together=set([('name', 'bp_verwaltungszeitraum')]),
        # ),
        # migrations.RemoveField(
        #     model_name='block',
        #     name='verwaltungszeitraum',
        # ),
        # migrations.AddField(
        #     model_name='block',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(default=0, related_name='bloecke', to='bp_cupid.BPVerwaltungszeitraum'),
        #     preserve_default=False,
        # ),

        migrations.AlterField(
            model_name='platzbegrenzung',
            name='verwaltungszeitraum',
            field=models.ForeignKey(
                related_name='platzbegrenzung',
                to='bp_cupid.BPVerwaltungszeitraum'
            ),
        ),
        migrations.RenameField(
            model_name='platzbegrenzung',
            old_name='verwaltungszeitraum',
            new_name='bp_verwaltungszeitraum',
        ),

        # migrations.AlterUniqueTogether(
        #     name='platzbegrenzung',
        #     unique_together=set([('bp_verwaltungszeitraum', 'praxis')]),
        # ),
        # migrations.RemoveField(
        #     model_name='platzbegrenzung',
        #     name='verwaltungszeitraum',
        # ),
        # migrations.AddField(
        #     model_name='platzbegrenzung',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(default=0, related_name='platzbegrenzung', to='bp_cupid.BPVerwaltungszeitraum'),
        #     preserve_default=False,
        # ),

        migrations.AlterField(
            model_name='zusatzinfopraxis',
            name='verwaltungszeitraum',
            field=models.ForeignKey(to='bp_cupid.BPVerwaltungszeitraum'),
        ),
        migrations.RenameField(
            model_name='zusatzinfopraxis',
            old_name='verwaltungszeitraum',
            new_name='bp_verwaltungszeitraum',
        ),

        # migrations.AlterUniqueTogether(
        #     name='zusatzinfopraxis',
        #     unique_together=set([('praxis', 'bp_verwaltungszeitraum')]),
        # ),
        # migrations.RemoveField(
        #     model_name='zusatzinfopraxis',
        #     name='verwaltungszeitraum',
        # ),
        # migrations.AddField(
        #     model_name='zusatzinfopraxis',
        #     name='bp_verwaltungszeitraum',
        #     field=models.ForeignKey(default=0, to='bp_cupid.BPVerwaltungszeitraum'),
        #     preserve_default=False,
        # ),

        # Wir brauchen nichts zu löschen, das wird auch von RenameField
        # übernommen.
        # migrations.DeleteModel(
        #     name='Verwaltungszeitraum',
        # ),
    ]
