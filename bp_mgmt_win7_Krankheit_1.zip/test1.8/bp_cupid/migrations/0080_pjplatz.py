# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0079_pjzeitraum'),
    ]

    operations = [
        migrations.CreateModel(
            name='PJPlatz',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, default=0, serialize=False, auto_created=True)),
                ('student', models.ForeignKey(related_name='pjplatz', to='bp_cupid.Student')),
                ('kommentar', models.TextField(blank=True, default='')),
                ('pj_zeitraum', models.ForeignKey(verbose_name='PJ-Zeitraum', related_name='pj_plaetze', to='bp_cupid.PJZeitraum')),
                ('praxis', models.ForeignKey(related_name='pjplatz_related', to='bp_cupid.Praxis')),
            ],
            options={
                'verbose_name': 'PJ-Platz',
                'verbose_name_plural': 'PJ-Plätze',
                'ordering': ['pj_zeitraum'],
            },
        ),
        migrations.AlterUniqueTogether(
            name='pjplatz',
            unique_together=set([('student', 'pj_zeitraum'), ('praxis', 'pj_zeitraum')]),
        ),
    ]
