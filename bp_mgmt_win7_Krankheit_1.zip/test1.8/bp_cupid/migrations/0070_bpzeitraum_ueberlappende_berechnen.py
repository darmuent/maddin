# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations
from bp_cupid.models import BPZeitraum

def aktualisiere_ueberlappende_bp_zeitraeume(apps, schema_editor):
    for zr in BPZeitraum.objects.all():
        zr.aktualisiere_bp_zeitraeume()

def entferne_ueberlappende_bp_zeitraeume(apps, schema_editor):
    for zeitraum in BPZeitraum.objects.all():
        for z in zeitraum.ueberlappende.all():
            zeitraum.ueberlappende.remove(z)

class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0069_zeitraum_zu_bpzeitraum'),
    ]

    operations = [
        migrations.RunPython(
            aktualisiere_ueberlappende_bp_zeitraeume,
            reverse_code=entferne_ueberlappende_bp_zeitraeume
        ),
    ]
