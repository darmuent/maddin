# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.db.models.deletion
import django.core.validators
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('bp_cupid', '0070_bpzeitraum_ueberlappende_berechnen'),
    ]

    operations = [
        # Platz → BPPlatz
        #
        # migrations.CreateModel(
        #     name='BPPlatz',
        #     fields=[
        #         ('student', models.OneToOneField(primary_key=True, serialize=False, related_name='bpplatz', to='bp_cupid.Student')),
        #         ('kommentar', models.TextField(blank=True, default='')),
        #         ('manuell', models.BooleanField(default=False, help_text='Wenn aktiviert, dann wird der Platz bei der automatischen Platzvergabe nicht gelöscht.')),
        #     ],
        #     options={
        #         'verbose_name': 'BP-Platz',
        #         'verbose_name_plural': 'BP-Plätze',
        #         'ordering': ['bp_zeitraum'],
        #     },
        # ),
        # migrations.AddField(
        #     model_name='bpplatz',
        #     name='bp_zeitraum',
        #     field=models.ForeignKey(related_name='bp_plaetze', to='bp_cupid.BPZeitraum'),
        # ),
        # migrations.AddField(
        #     model_name='bpplatz',
        #     name='praxis',
        #     field=models.ForeignKey(related_name='bpplatz_related', to='bp_cupid.Praxis'),
        # ),
        # migrations.AlterUniqueTogether(
        #     name='platz',
        #     unique_together=set([]),
        # ),
        # migrations.RemoveField(
        #     model_name='platz',
        #     name='bp_zeitraum',
        # ),
        # migrations.RemoveField(
        #     model_name='platz',
        #     name='praxis',
        # ),
        # migrations.RemoveField(
        #     model_name='platz',
        #     name='student',
        # ),

        migrations.RenameModel(
            old_name='Platz',
            new_name='BPPlatz',
        ),
        migrations.AlterModelOptions(
            name='BPPlatz',
            options={
                'verbose_name': 'BP-Platz',
                'verbose_name_plural': 'BP-Plätze',
                'ordering': ['bp_zeitraum'],
            },
        ),
        migrations.AlterField(
            model_name='BPPlatz',
            name='student',
            field=models.OneToOneField(
                primary_key=True,
                related_name='bpplatz',
                to='bp_cupid.Student'
            ),
        ),
        migrations.AlterField(
            model_name='BPPlatz',
            name='praxis',
            field=models.ForeignKey(
                related_name='bpplatz_related',
                to='bp_cupid.Praxis'
            ),
        ),

        # ???:
        # migrations.AlterField(
        #     model_name='bpzeitraum',
        #     name='bp_block',
        #     field=models.ForeignKey(verbose_name='BP-Block', related_name='bp_zeitraeume', to='bp_cupid.BPBlock'),
        # ),
        # migrations.DeleteModel(
        #     name='HistoricalPlatz',
        # ),
        # migrations.DeleteModel(
        #     name='Platz',
        # ),
        # migrations.DeleteModel(
        #     name='Platzbegrenzung',
        # ),
        # migrations.AlterUniqueTogether(
        #     name='bpplatzbegrenzung',
        #     unique_together=set([('bp_verwaltungszeitraum', 'praxis')]),
        # ),
        # migrations.AlterUniqueTogether(
        #     name='bpplatz',
        #     unique_together=set([('praxis', 'bp_zeitraum')]),
        # ),
    ]
