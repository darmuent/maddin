# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
from django.conf import settings
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('bp_cupid', '0074_delete_historicalplatz'),
    ]

    operations = [
        migrations.CreateModel(
            name='HistoricalBPPlatz',
            fields=[
                (
                    'student',
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        related_name='+',
                        on_delete=django.db.models.deletion.DO_NOTHING,
                        to='bp_cupid.Student',
                        db_constraint=False
                    )
                ),
                (
                    'praxis',
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        related_name='+',
                        on_delete=django.db.models.deletion.DO_NOTHING,
                        to='bp_cupid.Praxis',
                        db_constraint=False
                    )
                ),
                (
                    'bp_zeitraum',
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        related_name='+',
                        on_delete=django.db.models.deletion.DO_NOTHING,
                        to='bp_cupid.BPZeitraum',
                        db_constraint=False
                    )
                ),
                (
                    'kommentar',
                    models.TextField(
                        blank=True,
                        default=''
                    )
                ),
                (
                    'manuell',
                    models.BooleanField(
                        default=False,
                        help_text='Wenn aktiviert, dann wird der Platz bei der automatischen Platzvergabe nicht gelöscht.'
                    )
                ),
                (
                    'history_id',
                    models.AutoField(
                        primary_key=True,
                        serialize=False
                    )
                ),
                (
                    'history_date',
                    models.DateTimeField()
                ),
                (
                    'history_change_reason',
                    models.CharField(
                        max_length=100,
                        null=True
                    )
                ),
                (
                    'history_user',
                    models.ForeignKey(
                        null=True,
                        related_name='+',
                        on_delete=django.db.models.deletion.SET_NULL,
                        to=settings.AUTH_USER_MODEL
                    )
                ),
                (
                    'history_type',
                    models.CharField(
                        max_length=1,
                        choices=[
                            ('+', 'Created'),
                            ('~', 'Changed'),
                            ('-', 'Deleted')
                        ]
                    )
                ),
            ],
            options={
                'verbose_name': 'historical BP-Platz',
                'ordering': ('-history_date', '-history_id'),
                'get_latest_by': 'history_date',
            },
        ),
    ]
