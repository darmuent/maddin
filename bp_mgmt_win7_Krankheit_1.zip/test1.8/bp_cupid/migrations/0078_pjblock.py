# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0077_pjverwaltungszeitraum'),
    ]

    operations = [
        migrations.CreateModel(
            name='PJBlock',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('name', models.CharField(max_length=20)),
                ('pj_verwaltungszeitraum', models.ForeignKey(verbose_name='PJ-Verwaltungszeitraum', related_name='pj_bloecke', to='bp_cupid.PJVerwaltungszeitraum')),
            ],
            options={
                'verbose_name': 'PJ-Block',
                'verbose_name_plural': 'PJ-Blöcke',
            },
        ),
        migrations.AlterUniqueTogether(
            name='pjblock',
            unique_together=set([('name', 'pj_verwaltungszeitraum')]),
        ),
    ]
