# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0081_pj_zeitraeume_bei_praxis_und_pjzeitraum'),
    ]

    operations = [
        migrations.AlterField(
            model_name='pjplatz',
            name='id',
            field=models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True),
        ),
    ]
