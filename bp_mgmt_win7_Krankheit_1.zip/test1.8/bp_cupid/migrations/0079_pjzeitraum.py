# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0078_pjblock'),
    ]

    operations = [
        migrations.CreateModel(
            name='PJZeitraum',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('anfang', models.DateField()),
                ('ende', models.DateField()),
                ('pj_block', models.ForeignKey(verbose_name='PJ-Block', related_name='pj_zeitraeume', to='bp_cupid.PJBlock')),
            ],
            options={
                'verbose_name': 'PJ-Zeitraum',
                'verbose_name_plural': 'PJ-Zeiträume',
                'ordering': ['anfang'],
            },
        ),
    ]
