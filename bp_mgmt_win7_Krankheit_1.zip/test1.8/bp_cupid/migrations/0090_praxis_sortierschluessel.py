# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0089_loesche_bpverwaltungszeitraum_aus_abrechnungsdetail'),
    ]

    operations = [
        migrations.AddField(
            model_name='praxis',
            name='sortierschluessel',
            field=models.CharField(verbose_name='Sortierschlüssel', max_length=100, blank=True, null=True, help_text='Wenn gesetzt, dann wird die Praxis danach einsortiert, ansonsten nach dem Namen.'),
        ),
    ]
