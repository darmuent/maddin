# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0049_evaluation_note_praktikum_nicht_mehr_zwingend'),
    ]

    operations = [
        migrations.AddField(
            model_name='block',
            name='kapazitaet',
            field=models.IntegerField(verbose_name='Kapazität', default=0),
        ),
    ]
