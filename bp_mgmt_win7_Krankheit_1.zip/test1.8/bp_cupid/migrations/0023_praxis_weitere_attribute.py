# -*- coding: utf-8 -*-
# flake8: noqa

from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0022_platz_onetoone_student'),
    ]

    operations = [
        migrations.AddField(
            model_name='praxis',
            name='belegte_zeitraeume',
            field=models.ManyToManyField(to='bp_cupid.Zeitraum', blank=True, db_table='praxis_zeitraum_belegt', verbose_name='belegte Zeiträume', related_name='praxen_belegt'),
        ),
        migrations.AddField(
            model_name='praxis',
            name='freie_zeitraeume',
            field=models.ManyToManyField(to='bp_cupid.Zeitraum', blank=True, db_table='praxis_zeitraum_frei', verbose_name='freie Zeiträume', related_name='praxen_frei'),
        ),
        migrations.AddField(
            model_name='praxis',
            name='hat_didaktikschulung_besucht',
            field=models.BooleanField(default=False, verbose_name='hat Didaktikschulung besucht'),
        ),
        migrations.AddField(
            model_name='praxis',
            name='ist_aktiv',
            field=models.BooleanField(default=True, verbose_name='ist aktiv'),
        ),
        migrations.AddField(
            model_name='praxis',
            name='interne_notizen',
            field=models.TextField(verbose_name='interne Notizen', blank=True, default=''),
        ),
        migrations.AddField(
            model_name='praxis',
            name='ist_landarztpraxis',
            field=models.BooleanField(verbose_name='ist Landarztpraxis', default=False),
        ),
    ]
