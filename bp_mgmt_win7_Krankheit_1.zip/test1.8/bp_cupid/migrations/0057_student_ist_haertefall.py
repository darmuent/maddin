# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('bp_cupid', '0056_adds_historicalfields'),
    ]

    operations = [
        migrations.AddField(
            model_name='historicalstudent',
            name='ist_haertefall',
            field=models.BooleanField(verbose_name='ist Härtefall', default=False, help_text='Wenn aktiv, dann wird der/die Studierende vorrangig an eine Praxis aus Rostock verteilt.'),
        ),
        migrations.AddField(
            model_name='student',
            name='ist_haertefall',
            field=models.BooleanField(verbose_name='ist Härtefall', default=False, help_text='Wenn aktiv, dann wird der/die Studierende vorrangig an eine Praxis aus Rostock verteilt.'),
        ),
    ]
