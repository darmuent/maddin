from django.db.models.signals import post_save, post_delete, m2m_changed
from django.dispatch import receiver

from .models import (
    BPBlock,
    BPPlatz,
    BPVerwaltungszeitraum,
    BPZeitraum,
    PJPlatz,
    PJZeitraum,
    Praxis,
    Student,
)
from .tasks import (
    berechne_gewichte_von_praxis,
    berechne_gewichte_von_student,
)

import logging
logger = logging.getLogger(__name__)


# TODO: die Relation der Signale und Funktionen tabellarisch darstellen
# -> Welche Funktion wird bei welchem Signal von welchem Model aufgerufen?


@receiver(post_save, sender=Praxis)
def aktualisiere_zeitraeume_nach_praxisspeicherung(sender, instance, **kwargs):
    """
    Wir können die BP-Zeiträume erst aktualisieren, wenn die Praxis in der
    Datenbank gespeichert wurde (und damit eine id hat):
    """
    logger.debug(
        'Praxis [post_save, m2m_changed]: '
        'aktualisiere BP- und PJ-Zeiträume von {}.'.format(instance)
    )
    instance.aktualisiere_zeitraeume()


"""
Hier aktualisieren wir die BP- und PJ-Zeiträume einer Praxis immer dann, wenn
die ManyToMany-Beziehung Praxis-BPZeitraum und Praxis-PJZeitraum geändert wird:
"""
m2m_changed.connect(
    receiver=aktualisiere_zeitraeume_nach_praxisspeicherung,
    sender=Praxis.bp_zeitraeume.through,
)
m2m_changed.connect(
    receiver=aktualisiere_zeitraeume_nach_praxisspeicherung,
    sender=Praxis.pj_zeitraeume.through,
)


@receiver(post_save, sender=Praxis)
def aktualisiere_gewichte_nach_praxisspeicherung(sender, instance, **kwargs):
    logger.debug(
        'Praxis [post_save]: '
        'berechne Gewichte von {}.'.format(instance)
    )
    berechne_gewichte_von_praxis.delay(instance.id)


@receiver(post_save, sender=Student)
def aktualisiere_gewichte_nach_studentenspeicherung(sender, instance, **kwargs): # noqa
    logger.debug(
        'Student [post_save]: '
        'berechne Gewichte von {}.'.format(instance)
    )
    berechne_gewichte_von_student.delay(instance.id)


@receiver([post_save, post_delete], sender=BPPlatz)
def aktualisiere_zeitraeume_nach_bpplatzaenderung(sender, instance, **kwargs):
    """
    Aktualisiert die Zeiträume einer Praxis nach einer BP-Platzänderung.
    """
    praxis = instance.praxis
    bp_zeitraum = instance.bp_zeitraum
    bp_verwaltungszeitraum = bp_zeitraum.bp_block.bp_verwaltungszeitraum
    logger.debug(
        'BPPlatz [post_save, post_delete]: '
        'aktualisiere BP- und PJ-Zeiträume von {}.'.format(praxis)
    )
    praxis.aktualisiere_zeitraeume(bp_verw_zr=bp_verwaltungszeitraum)


@receiver([post_save, post_delete], sender=PJPlatz)
def aktualisiere_zeitraeume_nach_pjplatzaenderung(sender, instance, **kwargs):
    """
    Aktualisiert die Zeiträume einer Praxis nach einer PJ-Platzänderung.
    """
    praxis = instance.praxis
    pj_zeitraum = instance.pj_zeitraum
    pj_verwaltungszeitraum = pj_zeitraum.pj_block.pj_verwaltungszeitraum
    logger.debug(
        'PJPlatz [post_save, post_delete]: '
        'aktualisiere BP- und PJ-Zeiträume von {}.'.format(praxis)
    )
    praxis.aktualisiere_zeitraeume(pj_verw_zr=pj_verwaltungszeitraum)


@receiver(post_save, sender=BPZeitraum)
@receiver(post_save, sender=PJZeitraum)
def aktualisiere_ueberlappende_zeitraeume(sender, instance, **kwargs):
    """
    Aktualisiert die überlappenden Zeiträume, wenn ein BP- bzw. PJ-Zeitraum
    gespeichert wird.
    """
    name = instance._meta.object_name
    logger.debug(
        '{} [post_save]: '
        'aktualisiere überlappende BP- und PJ-Zeiträume von {}'.format(
            name,
            instance
        )
    )
    instance.aktualisiere_zeitraeume()


@receiver([post_save, post_delete], sender=BPZeitraum)
def aktualisiere_bp_block_nach_bp_zeitraumaenderung(sender, instance, **kwargs): # noqa
    """
    Aktualisiert BP-Blockkapazität.
    """
    bp_block = instance.bp_block
    logger.debug(
        'BPZeitraum [post_save, post_delete]: '
        'aktualisiere die BP-Blockkapazität von {}'.format(bp_block)
    )
    bp_block.save()


@receiver(post_save, sender=BPVerwaltungszeitraum)
def aktualisiere_bp_bloecke_nach_bp_verwaltungszeitraumspeicherung(sender, instance, **kwargs): # noqa
    """
    Aktualisiert die BP-Blockkapazitäten.
    """
    bp_verwaltungszeitraum = instance
    logger.debug(
        'BPVerwaltungszeitraum [post_save]: '
        'aktualisiere die Kapazitäten der BP-Blöcke von {}'.format(
            bp_verwaltungszeitraum
        )
    )
    for bp_block in bp_verwaltungszeitraum.bp_bloecke.all():
        bp_block.save()


def aktualisiere_bp_bloecke_nach_praxis_bp_zeitraum_m2m_aenderung(sender, instance, **kwargs): # noqa
    """
    Hier gehen wir mal auf Nummer sicher und aktualisieren die
    BP-Blockkapazitäten beim Ändern der Praxis-BPZeitraum-Relation.
    """
    bp_zeitraum_ids = kwargs['pk_set']
    if bp_zeitraum_ids:
        bp_bloecke = BPBlock.objects.filter(
            bp_zeitraeume__in=bp_zeitraum_ids
        ).distinct()

        logger.debug(
            'Praxis-BPZeitraum [m2m_changed]: '
            'aktualisiere die BP-Blockkapazitäten von {}'.format(bp_bloecke)
        )

        for bp_block in bp_bloecke:
            bp_block.save()


m2m_changed.connect(
    receiver=aktualisiere_bp_bloecke_nach_praxis_bp_zeitraum_m2m_aenderung,
    sender=Praxis.bp_zeitraeume.through,
)
