from django.core.exceptions import ValidationError
from django.core.urlresolvers import reverse
from django.db import models


class Verwaltungszeitraum(models.Model):
    class Meta:
        abstract = True

    name = models.CharField(
        max_length=50,
        unique=True
    )
    anfang = models.DateField()
    ende = models.DateField()

    def clean(self):
        if not (self.name and self.anfang and self.ende):
            return ValidationError(
                'Ein Verwaltungszeitraum braucht immer einen Namen, '
                'einen Anfang und ein Ende.'
            )
        if self.anfang > self.ende:
            raise ValidationError('Das Ende darf nicht vor dem Anfang sein.')


class BPVerwaltungszeitraum(Verwaltungszeitraum):
    class Meta:
        verbose_name = 'BP-Verwaltungszeitraum'
        verbose_name_plural = 'BP-Verwaltungszeiträume'

    plaetze_fuer_studenten_einsehbar = models.BooleanField(
        default=False,
        verbose_name='BP-Plätze sind für Studenten einsehbar',
        help_text=(
            'Wenn aktiviert, dann werden die zugewiesenen BP-Plätze auf der '
            'Startseite der Studenten angezeigt.'
        )
    )
    anzeige_fuer_fragebogen = models.TextField(
        verbose_name='Anzeige für den Fragebogen',
        help_text=(
            'So wird der dem Studenten zugeordnete BP-Verwaltungszeitraum '
            'in der Überschrift des Fragebogens angezeigt. Für den '
            'Verwaltungszeitraum „WS1617“ könnte dieser Text bspw. '
            '„WS 2016-17 und SS 2017“ sein.'
        ),
        default='',
        blank=True,
    )

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse(
            'bp_cupid:bpverwaltungszeitraum_detail',
            args=[str(self.id)]
        )


class PJVerwaltungszeitraum(Verwaltungszeitraum):
    """
    Ein Verwaltungszeitraum für ein "Praktisches Jahr".
    """
    class Meta:
        verbose_name = 'PJ-Verwaltungszeitraum'
        verbose_name_plural = 'PJ-Verwaltungszeiträume'

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse(
            'bp_cupid:pjverwaltungszeitraum_detail',
            args=[str(self.id)],
        )
