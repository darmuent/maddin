"""
Ein Block.
"""

from django.core.urlresolvers import reverse
from django.db import models

try:
    from django.apps import apps
    get_model = apps.get_model
except ImportError:
    from django.db.models.loading import get_model

from . import (
    BPVerwaltungszeitraum,
    PJVerwaltungszeitraum,
)


class Block(models.Model):
    class Meta:
        abstract = True

    name = models.CharField(max_length=20)


class BPBlock(Block):
    """
    Ein Block ist immer einem BP-Verwaltungszeitraum zugeordnet und hat einen
    Namen. Der Name muss nicht eindeutig sein, da ja in jedem
    BP-Verwaltungszeitraum die Blöcke wieder von 1 bis n durchnummeriert
    werden.

    Dafür müssen Name + BP-Verwaltungszeitraum eindeutig sein.
    """
    class Meta:
        verbose_name = 'BP-Block'
        verbose_name_plural = 'BP-Blöcke'
        unique_together = ('name', 'bp_verwaltungszeitraum')

    def get_absolute_url(self):
        return reverse('bp_cupid:bpblock_detail', args=[str(self.id)])

    def __str__(self):
        return '{} ({})'.format(self.name, self.bp_verwaltungszeitraum)

    bp_verwaltungszeitraum = models.ForeignKey(
        BPVerwaltungszeitraum,
        related_name='bp_bloecke',
        verbose_name='BP-Verwaltungszeitraum',
    )
    kapazitaet = models.IntegerField(
        default=0,
        verbose_name='Kapazität',
    )

    def zeiten(self):
        """
        Macht die Zeiträume für die Adminseiten zurecht und gibt sie zurück.
        """
        return '<br />'.join(map(str, self.bp_zeitraeume.all()))
    zeiten.allow_tags = True
    zeiten.short_description = 'Zeiträume'

    @property
    def anzahl_bp_plaetze(self):
        """
        Gibt die Anzahl aller BP-Plätze des BP-Blocks zurück.
        """
        anzahl = 0
        bp_zeitraeume = self.bp_zeitraeume.all()
        for bp_zr in bp_zeitraeume:
            anzahl += bp_zr.bp_plaetze.count()
        return anzahl

    def maximale_kapazitaet(self):
        """
        Gibt die maximale Kapazität des BP-Blocks zurück.

        Dazu gehen wir alle Praxen durch und summieren die Kapazitäten für
        diesen Block.
        """
        Praxis = get_model('bp_cupid', 'Praxis')
        return Praxis.objects.filter(
                bp_zeitraeume__bp_block=self
            ).distinct().count()

    def anzahl_freie_bp_plaetze(self):
        """
        Gibt die Anzahl freier BP-Plätze des Blocks zurück.
        """
        anzahl_bp_plaetze = self.anzahl_bp_plaetze
        diff = self.kapazitaet - anzahl_bp_plaetze

        if diff >= 0:
            return diff
        else:
            return self.maximale_kapazitaet() - anzahl_bp_plaetze

    def bp_plaetze(self):
        """
        Gibt alle BP-Plätze dieses BP-Blocks zurück.
        """
        BPPlatz = get_model('bp_cupid', 'BPPlatz')
        bp_zeitraeume = self.bp_zeitraeume.all()
        return BPPlatz.objects.filter(
                bp_zeitraum__in=bp_zeitraeume
            ).prefetch_related(
                'student',
            ).order_by('student__name')

    def save(self, *args, **kwargs):
        self.kapazitaet = self.maximale_kapazitaet()
        super(self.__class__, self).save(*args, **kwargs)


class PJBlock(Block):
    class Meta:
        verbose_name = 'PJ-Block'
        verbose_name_plural = 'PJ-Blöcke'
        unique_together = ('name', 'pj_verwaltungszeitraum')

    def get_absolute_url(self):
        return reverse('bp_cupid:pjblock_detail', args=[str(self.id)])

    def __str__(self):
        return '{} ({})'.format(self.name, self.pj_verwaltungszeitraum)

    pj_verwaltungszeitraum = models.ForeignKey(
        PJVerwaltungszeitraum,
        related_name='pj_bloecke',
        verbose_name='PJ-Verwaltungszeitraum',
    )
