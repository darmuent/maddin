"""
Zusätzliche Informationen für Mitarbeiter.
"""

from django.db import models
from django.conf import settings
from . import BPVerwaltungszeitraum


class Mitarbeiter(models.Model):
    """
    Um Informationen wie den aktuell eingestellten BP-Verwaltungszeitraum zu
    speichern, müssen wir eine Proxyklasse zu User erstellen, in der wir die
    zusätzlichen Infos ablegen. Siehe dazu
    https://docs.djangoproject.com/en/1.8/topics/auth/customizing/#extending-the-existing-user-model
    """
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        primary_key=True,
    )
    akt_bp_verw_zeitraum = models.ForeignKey(
        BPVerwaltungszeitraum,
        default=1,
        verbose_name='aktueller BP-Verwaltungszeitraum',
        help_text=(
            'Bei allen Ansichten werden nur Blöcke und Zeiträume des '
            'aktuellen BP-Verwaltungszeitraums angezeigt.'
        )
    )

    class Meta:
        verbose_name = 'Mitarbeiter'
        verbose_name_plural = 'Mitarbeiter'

    def __str__(self):
        return self.user.get_full_name()
