from rest_framework import serializers

from ..models import (
    Praxis,
    Vorlage,
)


class VorlagenSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vorlage
        fields = ('token', 'text')
        read_only_fields = ('token', )


class PraxisSerializer(serializers.ModelSerializer):
    class Meta:
        model = Praxis
        fields = '__all__'


class PraxisPositionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Praxis
        fields = (
            'id',
            'anrede',
            'vorname',
            'name',
            'adresse',
            'plz',
            'ort',
            'position',
            'ist_vip',
            'telefon',
        )
