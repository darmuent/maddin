from rest_framework import generics
from rest_framework.permissions import AllowAny

from .serializers import (
    PraxisPositionSerializer,
    PraxisSerializer,
    VorlagenSerializer,
)

from ..models import (
    Praxis,
    Vorlage,
)


class VorlagenDetail(generics.RetrieveAPIView):
    queryset = Vorlage.objects.all()
    serializer_class = VorlagenSerializer
    lookup_field = 'token'


class PraxisDetail(generics.RetrieveAPIView):
    queryset = Praxis.objects.all()
    serializer_class = PraxisSerializer
    lookup_field = 'id'


class PraxisPositionDetail(generics.RetrieveAPIView):
    queryset = Praxis.objects.all()
    permission_classes = (AllowAny, )
    serializer_class = PraxisPositionSerializer
    lookup_field = 'id'


class PraxisPositionList(generics.ListAPIView):
    permission_classes = (AllowAny, )
    serializer_class = PraxisPositionSerializer
    lookup_field = 'id'

    def get_queryset(self):
        praxen = Praxis.objects.filter(ist_aktiv=True)
        praxen_mit_position = [praxis for praxis in praxen if praxis.position]
        return praxen_mit_position
