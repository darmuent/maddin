from . import urls # noqa
