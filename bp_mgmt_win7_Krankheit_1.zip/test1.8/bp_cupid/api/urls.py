from django.conf.urls import url
from rest_framework.urlpatterns import format_suffix_patterns

from .views import (
    PraxisDetail,
    PraxisPositionDetail,
    PraxisPositionList,
    VorlagenDetail,
)


urlpatterns = [
    url(
        r'^praxis/(?P<id>\d+)/$',
        PraxisDetail.as_view(),
        name='praxis_detail',
    ),
    url(
        r'^praxis/geo/(?P<id>\d+)/$',
        PraxisPositionDetail.as_view(),
        name='praxis_position_detail',
    ),
    url(
        r'^praxis/geo/$',
        PraxisPositionList.as_view(),
        name='praxis_position_list',
    ),
    url(
        r'^vorlage/(?P<token>[-\w]+)/$',
        VorlagenDetail.as_view(),
        name='vorlage'
    ),
]

urlpatterns = format_suffix_patterns(urlpatterns)
