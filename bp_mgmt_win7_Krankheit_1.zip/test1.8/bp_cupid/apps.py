from django.apps import AppConfig, apps
from actstream import registry
from watson import search as watson


class BPCupidConfig(AppConfig):
    name = 'bp_cupid'
    verbose_name = 'BP Cupid'

    def ready(self):
        registry.register(apps.get_model('auth.user'))
        registry.register(apps.get_model('bp_cupid.Student'))
        registry.register(apps.get_model('bp_cupid.Praxis'))
        registry.register(apps.get_model('bp_cupid.BPVerwaltungszeitraum'))

        from . import signals

        Student = self.get_model('Student')
        watson.register(
            Student,
            fields=('mat_nr', ),
        )
        Praxis = self.get_model('Praxis')
        watson.register(Praxis)
